# Battle Zone V6 — Clean package and linkage audit

This report records static checks only. It does not claim a successful Gradle build, running game, or Android-device test.

## Cleanup performed
- Removed Python bytecode/cache files and temporary download/backup artifacts from the package.
- Preserved project source, original game backup, documentation, bundled assets, and license notices.
- Did not create fake Three.js libraries, placeholder animations, or fabricated model files.

## Static linkage results
- Main WebView entry: `app/src/main/assets/www/index.html`
- Script references in index.html: 7
- Referenced local scripts missing from disk: ./libs/three.min.js, ./libs/GLTFLoader.js, ./libs/fflate.min.js, ./libs/FBXLoader.js, ./libs/SkeletonUtils.js
- Runtime libraries required by the HTML but missing from the ZIP: libs/three.min.js, libs/GLTFLoader.js, libs/fflate.min.js, libs/FBXLoader.js, libs/SkeletonUtils.js
- Kenney character FBX/image assets found: 9

## Important limitations
- Three.js r128 and classic loader scripts are not bundled. The Gradle pre-build task attempts to download them, so first build requires network access. Offline launch cannot be guaranteed until the exact runtime libraries are bundled and tested.
- The character-animation helper is source code only; it is not claimed to be wired into the gameplay loop.
- Environment texture packs are bundled. Some are integration examples/optional packs; the static audit does not prove every texture is used by the live map.
- LAN networking is a foundation, not verified full-authority multiplayer.
- No APK build or physical-device test was performed during this cleanup.

## Android Studio opening
Open the `BattleZoneLocalMultiplayer` folder (the folder containing `settings.gradle.kts`) in Android Studio. Use JDK 17 and allow Gradle to sync. Build a debug APK only after the dependency download succeeds.
