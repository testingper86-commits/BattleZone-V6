import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.battlezone"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.battlezone"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core-ktx:1.15.0")
}

// ---------------------------------------------------------------------------------------------
// Runtime files the game needs but that are NOT checked into the project. They are fetched
// automatically before every build (needs internet the first time only).
//   * Three.js r128 (classic build)  - REQUIRED, build fails with instructions if unobtainable
//   * GLTFLoader + SkeletonUtils r128 and soldier.glb - OPTIONAL (rigged remote-player model);
//     if they cannot be fetched the game keeps its built-in procedural characters.
// ---------------------------------------------------------------------------------------------
val wwwDir = layout.projectDirectory.dir("src/main/assets/www").asFile

fun download(urls: List<String>, target: File, minSize: Long, mustContain: String?, errors: MutableList<String>): Boolean {
    target.parentFile.mkdirs()
    for (src in urls) {
        try {
            val c = URL(src).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 90_000
            c.setRequestProperty("User-Agent", "BattleZone-Gradle"); c.instanceFollowRedirects = true
            if (c.responseCode != 200) { errors += "$src -> HTTP ${c.responseCode}"; continue }
            val tmp = File(target.parentFile, target.name + ".download")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val ok = tmp.length() >= minSize && (mustContain == null || tmp.readText(Charsets.ISO_8859_1).contains(mustContain))
            if (!ok) { tmp.delete(); errors += "$src -> unexpected content"; continue }
            if (target.exists()) target.renameTo(File(target.parentFile, target.name + ".replaced-backup"))
            tmp.renameTo(target)
            logger.lifecycle("Downloaded ${target.name} (${target.length() / 1024} KB) from $src")
            return true
        } catch (e: Exception) { errors += "$src -> ${e.javaClass.simpleName}: ${e.message}" }
    }
    return false
}

// ---- Three.js r128 (required) ----
val threeTarget = File(wwwDir, "libs/three.min.js")
fun looksLikeThree(f: File): Boolean =
    f.isFile && f.length() > 300_000 && f.readText(Charsets.ISO_8859_1).contains("REVISION")
// Exact version when the build states it ("REVISION=\"128\""), loose literal match otherwise.
fun isThreeR128(f: File): Boolean {
    if (!looksLikeThree(f)) return false
    val text = f.readText(Charsets.ISO_8859_1)
    val m = Regex("REVISION\\s*=\\s*[\"'](\\d+)[\"']").find(text)
    return if (m != null) m.groupValues[1] == "128" else Regex("[\"']128[\"']").containsMatchIn(text)
}

val downloadThreeJs = tasks.register("downloadThreeJs") {
    group = "battlezone"
    description = "Downloads Three.js r128 into assets/www/libs if it is missing or the wrong version."
    onlyIf { !isThreeR128(threeTarget) }
    doLast {
        val errors = mutableListOf<String>()
        val ok = download(listOf(
            "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
            "https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js",
            "https://unpkg.com/three@0.128.0/build/three.min.js"), threeTarget, 300_000, "REVISION", errors)
        if (!ok) {
            val msg = "Could not obtain Three.js r128.\n  " + errors.joinToString("\n  ") +
                "\nFix: connect to the internet and rebuild, or run 'python download_threejs.py'."
            if (looksLikeThree(threeTarget)) logger.warn("WARNING: $msg\nKeeping the existing libs/three.min.js (not r128 - rendering may differ).")
            else throw GradleException(msg)
        }
    }
}

// ---- Optional loaders (r128 classic builds from the three.js examples folder) ----
val downloadOptionalLibs = tasks.register("downloadOptionalLibs") {
    group = "battlezone"
    description = "Downloads GLTFLoader, FBXLoader, fflate, SkeletonUtils r128 (optional, for character models)."
    doLast {
        listOf("loaders/GLTFLoader.js" to "GLTFLoader.js", "loaders/FBXLoader.js" to "FBXLoader.js",
               "utils/SkeletonUtils.js" to "SkeletonUtils.js", "libs/fflate.min.js" to "fflate.min.js",
               "curves/NURBSCurve.js" to "NURBSCurve.js", "curves/NURBSUtils.js" to "NURBSUtils.js").forEach { (path, name) ->
            val target = File(wwwDir, "libs/$name")
            if (target.isFile && target.length() > 5_000) return@forEach
            val errors = mutableListOf<String>()
            val ok = download(listOf(
                "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/$path",
                "https://unpkg.com/three@0.128.0/examples/js/$path"), target, 5_000, null, errors)
            if (!ok) logger.warn("WARNING (optional): could not fetch $name - soldier model disabled.\n  " + errors.joinToString("\n  "))
        }
    }
}

// ---- Optional soldier models (CC BY 4.0, from github.com/cktang88/3d-fps) ----
val downloadSoldierModels = tasks.register("downloadSoldierModels") {
    group = "battlezone"
    description = "Downloads soldier.glb (+ licence notice) into assets/www/models/characters."
    doLast {
        val dir = File(wwwDir, "models/characters"); dir.mkdirs()
        val soldier = File(dir, "soldier.glb")
        if (soldier.isFile && soldier.length() > 10_000) return@doLast
        try {
            val c = URL("https://codeload.github.com/cktang88/3d-fps/zip/refs/heads/main").openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 120_000; c.setRequestProperty("User-Agent", "BattleZone-Gradle")
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            var found = 0
            ZipInputStream(c.inputStream).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name.lowercase()
                    if (!e.isDirectory && (n.endsWith("/models/characters/soldier.glb") || n.endsWith("/models/characters/soldier_tac.glb"))) {
                        File(dir, File(e.name).name).outputStream().use { o -> z.copyTo(o) }; found++
                    }
                    e = z.nextEntry
                }
            }
            if (found == 0) throw IllegalStateException("soldier.glb not found in the repository archive")
            File(dir, "THIRD_PARTY_LICENSE_NOTICE.txt").writeText(
                "Character models from https://github.com/cktang88/3d-fps.\n" +
                "soldier.glb: BAMEN, CC BY 4.0. soldier_tac.glb: DanlyVostok, CC BY 4.0. https://creativecommons.org/licenses/by/4.0/\n" +
                "Attribution is required if you distribute the game. Re-check upstream licences before publishing.\n")
            logger.lifecycle("Soldier models downloaded ($found file(s)).")
        } catch (e: Exception) {
            logger.warn("WARNING (optional): soldier model download failed (${e.message}). Procedural characters will be used.")
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(downloadThreeJs, downloadOptionalLibs)   // downloadSoldierModels is manual/optional (Kenney is bundled)
}
