# Battle Zone aircraft drop prototype

- Battle Royale begins with the player and bot roster aboard a shared transport aircraft.
- A procedural transport plane follows a route across the map.
- Player can jump on demand; bots jump in staggered waves, deploy a simplified parachute state and land.
- TDM and FFA start directly on the ground.

## Limitations
This is an offline AI/bot simulation. It does not create a real shared human lobby or synchronize airplane state across multiple devices. That requires the multiplayer transport protocol to carry match phase, flight route, jump events, player transforms and landing state. Aircraft, bot parachutes and animations are procedural prototypes and require Android device testing.
