# Character models
Shipped: Kenney "Animated Characters - Protagonists" (CC0) in `kenney/` (Model, Animations idle/run/jump, 4 skins, License.txt).
The game uses it automatically for: your own third-person body, offline bots/allies, and remote LAN players + LAN-bot avatars.
Each character/bot gets one of the 4 skins by name. There is no walk or shoot clip in this pack: walking uses the run clip slowed down.
(Low-quality profile keeps the light procedural bots for speed.)

Use another pack: create `manifest.json` here (see manifest.example.json):
{ "model":"./models/characters/<pack>/Model/x.fbx", "skins":["./models/characters/<pack>/Skins/a.png"],
  "anims":{"idle":"...idle.fbx","run":"...run.fbx","walk":"...walk.fbx","jump":"...jump.fbx"}, "height":1.8, "yawOffset":0, "walkScale":0.55 }
Backwards model -> "yawOffset": 3.14159.   .glb models also work (clips matched by name idle/run/walk/jump).
Diagnostics: Logcat tag BattleZoneWeb, lines starting "[models]".
IMPORTANT: FBXLoader must be the Three.js r128 *classic* script (examples/js/loaders/FBXLoader.js). The newer ES-module
FBXLoader (import ... from 'three') cannot run here. Gradle downloads the right one into www/libs automatically.
