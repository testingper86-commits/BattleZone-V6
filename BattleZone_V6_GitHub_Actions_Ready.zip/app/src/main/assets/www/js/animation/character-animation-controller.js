/* Battle Zone V6 - rig-compatible Three.js animation controller.
 * Integration helper only: supply a loaded skinned character and clips from a compatible/licensed asset.
 * Does not invent or include animation files. */
(function (root) {
  'use strict';
  class CharacterAnimationController {
    constructor(THREE, model, clips, options = {}) {
      if (!THREE || !model || !Array.isArray(clips)) throw new Error('THREE, model and clips are required');
      this.mixer = new THREE.AnimationMixer(model);
      this.actions = Object.create(null);
      this.current = null;
      this.dead = false;
      this.reloadLock = false;
      this.onFinished = options.onFinished || function () {};
      const aliases = options.aliases || { idle: ['idle','stand'], run: ['run','sprint','walk'], shoot: ['shoot','fire','rifle'], reload: ['reload'], death: ['death','die','dead'] };
      for (const clip of clips) {
        const n = String(clip.name || '').toLowerCase();
        for (const [state, keys] of Object.entries(aliases)) {
          if (!this.actions[state] && keys.some(k => n.includes(k))) this.actions[state] = this.mixer.clipAction(clip);
        }
      }
      this.mixer.addEventListener('finished', e => {
        const state = Object.keys(this.actions).find(k => this.actions[k] === e.action);
        if (state === 'reload') this.reloadLock = false;
        this.onFinished(state || 'unknown');
        if (state === 'shoot' || state === 'reload') this.play('idle');
      });
    }
    play(state, opts = {}) {
      if (this.dead && state !== 'death') return false;
      const action = this.actions[state];
      if (!action) return false; // missing clip is reported to caller; no silent fake animation
      if (this.current && this.current !== action) this.current.fadeOut(opts.fadeSeconds ?? 0.08);
      action.reset(); action.enabled = true; action.clampWhenFinished = state === 'death';
      action.setLoop(state === 'shoot' || state === 'reload' || state === 'death' ? 2200 : 2201, state === 'shoot' || state === 'reload' || state === 'death' ? 1 : Infinity);
      action.fadeIn(opts.fadeSeconds ?? 0.08).play(); this.current = action;
      if (state === 'reload') this.reloadLock = true;
      if (state === 'death') this.dead = true;
      return true;
    }
    shoot() { return !this.dead && !this.reloadLock && this.play('shoot'); }
    reload() { return !this.dead && !this.reloadLock && this.play('reload'); }
    die() { return this.play('death'); }
    update(deltaSeconds) { this.mixer.update(Math.min(Math.max(deltaSeconds || 0, 0), 0.1)); }
    available() { return Object.keys(this.actions); }
    dispose() { this.mixer.stopAllAction(); this.mixer.uncacheRoot(this.mixer.getRoot()); }
  }
  root.BattleZoneCharacterAnimationController = CharacterAnimationController;
})(typeof window !== 'undefined' ? window : globalThis);
