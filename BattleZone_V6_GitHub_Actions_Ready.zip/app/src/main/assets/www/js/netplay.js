/* Battle Zone LAN match layer (protocol v1 + combat events).
 * Host-authoritative: the room host validates every hit and owns health, kills, score and match end.
 * Clients only send "hit claims"; they accept hp/kill/roster/end events only when senderId === 'HOST'.
 * Message envelope (relayed by MainActivity): {kind:'combat', event:{t:...}, senderId}. */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const NET=window.BZNET={active:false,host:false,myId:null,mode:'tdm',myTeam:'blue',players:{},score:{blue:0,red:0},over:false,
  limit:{tdm:25,ffa:20},spawnProtMs:2500};
window.bzNetActive=false;

/* ---------- helpers ---------- */
const now=()=>performance.now();
function sendEv(ev){try{if(window.BattleNetwork)BattleNetwork.send(JSON.stringify({kind:'combat',event:ev}))}catch(e){}}
function myName(){const i=$('bz-player-name');return((i&&i.value)||(window.sg&&sg('bzname'))||'Player').trim().slice(0,20)||'Player'}
function nameOf(id){const p=NET.players[id];if(p)return p.n;return /^B\d+$/.test(String(id))?'Bot '+(Number(String(id).slice(1))+1):(id||'?')}
function spawnFor(team){
  const r=(a,b)=>a+Math.random()*(b-a);
  if(NET.mode==='tdm')return team==='red'?[r(30,60),r(-25,25)]:[r(-60,-30),r(-25,25)];
  return [r(-60,60),r(-60,60)];
}
function teleportMe(){
  const sp=spawnFor(NET.myTeam);P.x=sp[0];P.z=sp[1];P.y=1.6;P.vy=0;P.air=0;P.veh=null;P.down=0;
  try{setDrivingUI(false)}catch(e){}
}
window.bzNetIsEnemy=function(team){return NET.mode==='ffa'?true:team!==NET.myTeam};
function setMode(mode){
  NET.mode=(mode==='ffa')?'ffa':'tdm';
  BZ_MODE=NET.mode==='ffa'?'FFA':'TDM';
  try{ss('bzmode',BZ_MODE)}catch(e){}
  const mm=$('matchmode');if(mm)mm.textContent='Match: '+(NET.mode==='ffa'?'Free-for-All':'Team Deathmatch');
}
function activate(host,myId,mode){
  NET.active=true;NET.host=host;NET.myId=myId;NET.over=false;window.bzNetActive=true;setMode(mode);
  window.bzNetName=myName();hud();
}
function deactivate(){
  NET.active=false;NET.host=false;NET.myId=null;NET.players={};NET.score={blue:0,red:0};window.bzNetActive=false;window.bzNetTeam=null;
  const h=$('bz-net-hud');if(h)h.style.display='none';
}

/* ---------- HUD ---------- */
function ensureHud(){
  let h=$('bz-net-hud');
  if(!h){h=document.createElement('div');h.id='bz-net-hud';
    h.style.cssText='position:fixed;top:calc(8px + env(safe-area-inset-top,0px));left:50%;transform:translateX(-50%);z-index:30;pointer-events:none;'
     +'background:#0009;border:1px solid #ffffff30;border-radius:10px;padding:4px 12px;font:700 12px/1.35 system-ui,sans-serif;color:#fff;text-align:center;white-space:nowrap;display:none';
    document.body.appendChild(h)}
  return h;
}
function hud(){
  const h=ensureHud();if(!NET.active){h.style.display='none';return}
  const me=NET.players[NET.myId]||{k:0,d:0};
  if(NET.mode==='tdm'){
    h.innerHTML='<span style="color:#6db4ff">BLUE '+NET.score.blue+'</span> &nbsp;&ndash;&nbsp; <span style="color:#ff7a70">RED '+NET.score.red+'</span>'
     +' <small style="opacity:.8">/ '+NET.limit.tdm+'</small><br><small>'+esc(nameOf(NET.myId))+': '+me.k+'K '+me.d+'D</small>';
  }else{
    const top=Object.keys(NET.players).map(id=>[id,NET.players[id]]).sort((a,b)=>b[1].k-a[1].k).slice(0,3);
    h.innerHTML=top.map(([id,p],i)=>(i+1)+'. '+(id===NET.myId?'<b>':'')+esc(p.n)+' '+p.k+(id===NET.myId?'</b>':'')).join(' &nbsp; ')+' <small style="opacity:.8">/ '+NET.limit.ffa+'</small>';
  }
  h.style.display=(typeof started!=='undefined'&&started)?'block':'none';
}
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
setInterval(()=>{if(NET.active)hud()},500);

/* ---------- host: authoritative state ---------- */
function addPlayer(id,name){
  if(NET.players[id])return NET.players[id];
  let team='solo';
  if(NET.mode==='tdm'){const b=Object.values(NET.players).filter(p=>p.team==='blue').length,r=Object.values(NET.players).filter(p=>p.team==='red').length;team=b<=r?'blue':'red'}
  return NET.players[id]={n:String(name||id).slice(0,20),team,hp:100,alive:true,k:0,d:0,x:0,z:0,last:0,prot:0};
}
function roster(){
  const pl={};for(const id in NET.players){const p=NET.players[id];pl[id]={n:p.n,team:p.team,k:p.k,d:p.d}}
  return {t:'roster',mode:NET.mode,players:pl,score:NET.score};
}
function hostBroadcast(ev){sendEv(ev);applyEvent(ev,'HOST')}
function posOf(id){if(id==='HOST')return{x:P.x,z:P.z};const p=NET.players[id];return p?{x:p.x,z:p.z}:null}
const isBotId=id=>/^B\d+$/.test(String(id));
const findBot=id=>(typeof bots!=='undefined')?bots.find(b=>b.userData&&b.userData.nid===id):null;
function checkWin(s,shooterId){
  const win=NET.mode==='tdm'?(NET.score.blue>=NET.limit.tdm?'blue':NET.score.red>=NET.limit.tdm?'red':null)
                           :(s&&s.k>=NET.limit.ffa?shooterId:null);
  if(win){NET.over=true;hostBroadcast({t:'end',winner:win,roster:roster()})}
}
function creditKill(shooterId,s,victimId,w,head){
  s.k++;if(NET.mode==='tdm')NET.score[s.team]=(NET.score[s.team]||0)+1;
  hostBroadcast({t:'kill',victim:victimId,killer:shooterId,w:w|0,head:!!head});
  hostBroadcast(roster());checkWin(s,shooterId);
}
function hostHit(shooterId,ev){
  if(!NET.host||NET.over)return;
  const s=NET.players[shooterId],w=(typeof W!=='undefined')?W[ev.w|0]:null;
  if(!s||!w||shooterId===ev.target||!s.alive)return;
  const tm=now();if(tm-s.last<Math.max(30,w.r*1000*.7))return;       // fire-rate limit
  const mul=Math.min(1.5,Math.max(1,Number(ev.mul)||1)),dmgv=(ev.head?2:1)*w.d*mul;
  const sp=posOf(shooterId);if(!sp)return;
  if(isBotId(ev.target)){                                              // shooting a host-simulated bot
    const bot=findBot(ev.target);if(!bot||!bot.userData.alive)return;
    if(Math.hypot(sp.x-bot.position.x,sp.z-bot.position.z)>(w.f||150)+8)return;
    s.last=tm;bot.userData.hp-=dmgv;bot.userData.tx=sp.x;bot.userData.tz=sp.z;
    if(bot.userData.hp<=0){killBotNet(bot);creditKill(shooterId,s,ev.target,ev.w,ev.head)}
    else hostBroadcast({t:'hp',id:ev.target,hp:Math.round(bot.userData.hp),by:shooterId,dmg:Math.round(dmgv),head:!!ev.head});
    return;
  }
  const t=NET.players[ev.target];if(!t||!t.alive)return;
  if(NET.mode==='tdm'&&s.team===t.team)return;                         // no friendly fire
  if(tm<t.prot)return;                                                 // spawn protection
  const tp=posOf(ev.target);if(!tp||Math.hypot(sp.x-tp.x,sp.z-tp.z)>(w.f||150)+8)return; // range (+lag margin)
  s.last=tm;t.hp-=dmgv;
  if(t.hp>0){hostBroadcast({t:'hp',id:ev.target,hp:Math.round(t.hp),by:shooterId,dmg:Math.round(dmgv),head:!!ev.head});return}
  t.d++;t.hp=100;t.prot=tm+NET.spawnProtMs;
  creditKill(shooterId,s,ev.target,ev.w,ev.head);
  hostBroadcast({t:'hp',id:ev.target,hp:100,by:shooterId,dmg:0,respawn:true});
}

/* ---------- host-simulated bots (fill empty slots, hostile to everyone) ---------- */
function killBotNet(bot){
  bot.userData.alive=false;bot.rotation.x=-Math.PI/2;bot.position.y=.3;
  if(bot.userData.retired)return;
  setTimeout(()=>{ if(!NET.active||NET.over||bot.userData.retired)return;
    const r=(a,b)=>a+Math.random()*(b-a);bot.userData.hp=100;bot.userData.alive=true;bot.rotation.x=0;
    bot.position.x=r(-90,90);bot.position.z=r(-90,90);try{bot.position.y=gT(bot.position.x,bot.position.z)}catch(e){}
  },4000);
}
window.bzNetBotKilled=function(bot,byP){
  killBotNet(bot);
  if(byP&&NET.host&&NET.players.HOST)creditKill('HOST',NET.players.HOST,bot.userData.nid,P.w,false);
};
window.bzNetBotCount=function(){return NET.host?Math.max(0,(NET.limit.max||8)-Object.keys(NET.players).length):0};
window.bzNetTargets=function(){
  if(!NET.host)return[];const out=[];
  for(const id in NET.players){if(id==='HOST')continue;const p=NET.players[id];if(p.alive)out.push({id,x:p.x,z:p.z})}
  return out;
};
window.bzNetBotHit=function(bot,targetId,dmgv){
  if(!NET.host||NET.over)return;
  const t=NET.players[targetId];if(!t||!t.alive||now()<t.prot)return;
  t.hp-=dmgv;
  if(t.hp>0){hostBroadcast({t:'hp',id:targetId,hp:Math.round(t.hp),by:bot.userData.nid,dmg:Math.round(dmgv)});return}
  t.d++;t.hp=100;t.prot=now()+NET.spawnProtMs;
  hostBroadcast({t:'kill',victim:targetId,killer:bot.userData.nid,w:0,head:false});
  hostBroadcast({t:'hp',id:targetId,hp:100,by:bot.userData.nid,dmg:0,respawn:true});
  hostBroadcast(roster());
};
function retireBot(){ // a real player took a slot: remove one bot permanently
  if(typeof bots==='undefined')return;
  const b=bots.filter(x=>x.userData.nid&&!x.userData.retired).pop();
  if(b){b.userData.retired=true;b.userData.alive=false;b.visible=false;b.position.y=-50}
}
setInterval(()=>{ // snapshot of bots for clients (10 Hz)
  if(!NET.active||!NET.host||NET.over||typeof started==='undefined'||!started||typeof bots==='undefined')return;
  const arr=bots.filter(b=>b.userData.nid).map(b=>[b.userData.nid,+b.position.x.toFixed(2),+b.position.z.toFixed(2),+b.rotation.y.toFixed(2),(b.userData.alive&&!b.userData.retired)?1:0,Math.round(b.userData.hp)]);
  if(arr.length)sendEv({t:'bots',b:arr});
},100);

/* ---------- everyone: apply events ---------- */
function applyEvent(ev,from){
  if(!ev||typeof ev.t!=='string')return;
  if(from!=='HOST'&&ev.t!=='hit')return;                               // clients may only claim hits
  switch(ev.t){
   case 'roster':{
     NET.mode=ev.mode==='ffa'?'ffa':'tdm';NET.score=ev.score||NET.score;
     for(const id in NET.players)if(!ev.players[id])delete NET.players[id];
     for(const id in ev.players){const o=NET.players[id]||{hp:100,alive:true,x:0,z:0,last:0,prot:0};NET.players[id]=Object.assign(o,ev.players[id])}
     const me=NET.players[NET.myId];if(me){NET.myTeam=me.team;window.bzNetTeam=me.team;P.kills=me.k|0}
     if(!NET.host){BZ_MODE=NET.mode==='ffa'?'FFA':'TDM'}
     hud();break}
   case 'hp':{
     if(ev.id===NET.myId){
       const before=P.hp;P.hp=Math.max(1,Math.min(100,ev.hp));
       if(ev.hp<before&&!ev.respawn){try{snd(180,.1,.2);const f=$('flash');f.style.opacity=1;setTimeout(()=>f.style.opacity=0,120)}catch(e){}}
       if(ev.respawn){P.alive=true}
     }
     const a=window.bzRemotePlayers&&bzRemotePlayers.get(String(ev.id));if(a)a.hp=ev.hp;
     break}
   case 'kill':{
     const km=nameOf(ev.killer)+'  \u27A4  '+nameOf(ev.victim)+(ev.head?'  (headshot)':'');
     try{msg(km)}catch(e){}
     if(ev.victim===NET.myId){P.deaths=(P.deaths||0)+1;teleportMe();try{msg('Eliminated by '+nameOf(ev.killer)+' \u2022 respawned')}catch(e){}}
     if(ev.killer===NET.myId){try{hitMark();bzPlayEventVoice('combat')}catch(e){}}
     break}
   case 'bots':{
     if(NET.host)break;
     (ev.b||[]).forEach(r=>window.dispatchEvent(new CustomEvent('battle-zone-network-message',{detail:{kind:'player-state',senderId:r[0],state:{x:r[1],y:0,z:r[2],yaw:r[3]-Math.PI,alive:!!r[4],hp:r[5],team:'bot',name:nameOf(r[0])}}})));
     break}
   case 'start':{
     if(typeof started!=='undefined'&&!started&&!NET.host){
       try{msg('Host started the match')}catch(e){}
       try{$('go2').onclick();setTimeout(()=>{const g=$('pvgo');if(g)g.click()},500)}catch(e){}
     }break}
   case 'end':{
     NET.over=true;if(ev.roster)applyEvent(ev.roster,'HOST');
     const me=NET.players[NET.myId]||{k:0};P.kills=me.k;
     const win=NET.mode==='tdm'?(ev.winner===NET.myTeam):(ev.winner===NET.myId);
     try{end(win)}catch(e){}break}
  }
}

/* ---------- local shooting at remote players ---------- */
window.bzNetShoot=function(rc,wallDist){
  if(!NET.active||NET.over||typeof started==='undefined'||!started||!window.bzRemotePlayers)return;
  const parts=[];
  bzRemotePlayers.forEach((a,id)=>{
    if(!a.alive||!a.group.visible)return;
    const pl=NET.players[id];if(NET.mode==='tdm'&&pl&&pl.team===NET.myTeam)return;
    a.body.userData.pid=id;a.head.userData.pid=id;a.head.userData.isHead=1;parts.push(a.body,a.head)});
  if(!parts.length)return;
  const h=rc.intersectObjects(parts,false)[0];if(!h||h.distance>wallDist)return;
  const id=h.object.userData.pid,head=!!h.object.userData.isHead,w=W[P.w];
  try{hitMark();snd(1400,.04,.12,1);dn((head?2:1)*w.d,head)}catch(e){}
  const ev={t:'hit',target:id,w:P.w,head,mul:(typeof bzPowerStat==='function'?bzPowerStat('damage'):1)};
  if(NET.host)hostHit('HOST',ev);else sendEv(ev);
};
window.bzNetOnStart=function(){
  if(!NET.active)return;
  teleportMe();ensureHud();hud();
  if(NET.host)hostBroadcast({t:'start'});
};

/* ---------- wiring to Android bridge events ---------- */
window.addEventListener('battle-network',e=>{
  let d;try{d=JSON.parse(e.detail)}catch(_){return}
  if(d.type!=='status')return;const p=d.payload||{};
  if(p.state==='hosting'){
    deactivate();activate(true,'HOST',p.mode);
    const me=addPlayer('HOST',myName());me.team=NET.mode==='tdm'?'blue':'solo';NET.myTeam=me.team;window.bzNetTeam=me.team;
    NET.limit.max=p.maxPlayers;hud();
  }else if(p.state==='connected'){
    deactivate();activate(false,p.playerId,p.mode);
  }else if(p.state==='player-joined'&&NET.host){
    addPlayer(p.playerId,p.name);retireBot();hostBroadcast(roster());
  }else if(p.state==='player-left'&&NET.host){
    delete NET.players[p.playerId];hostBroadcast(roster());
  }else if(p.state==='peer-disconnected'||p.state==='disconnected'||p.state==='error'){
    if(p.state!=='error'||NET.active){const was=NET.active;deactivate();if(was){try{msg('Network session ended')}catch(_){}}}
  }
});
window.addEventListener('battle-zone-network-message',e=>{
  const m=e.detail||{};if(m.kind==='player-state'&&NET.host&&m.state&&NET.players[m.senderId]){
    const p=NET.players[m.senderId];p.x=Number(m.state.x)||0;p.z=Number(m.state.z)||0;return}
  if(m.kind!=='combat'||!m.event)return;
  const from=m.senderId==='HOST'?'HOST':String(m.senderId||'');
  if(m.event.t==='hit'){if(NET.host)hostHit(from,m.event);return}
  applyEvent(m.event,from);
});
/* Clean slate after "PLAY AGAIN" reloads the page: drop any leftover socket from the previous match. */
try{if(window.BattleNetwork)BattleNetwork.disconnect()}catch(e){}
})();
