/* Rigged character models (FBX e.g. Kenney "Animated Characters", or GLB) used for:
 *   - the local player's third-person body, offline/LAN bots and allies  (dress())
 *   - remote LAN players and LAN-bot avatars on other phones             (attach())
 * Config: models/characters/manifest.json, else the Kenney layout shipped in this project, else soldier.glb.
 * On ANY failure the built-in procedural characters stay. Needs r128 classic FBXLoader+fflate (or GLTFLoader) + SkeletonUtils. */
(function(){
'use strict';
const K='./models/characters/kenney/';
const DEFAULTS=[
 {format:'fbx',model:K+'Model/characterMedium.fbx',
  skins:[K+'Skins/skaterMaleA.png',K+'Skins/criminalMaleA.png',K+'Skins/cyborgFemaleA.png',K+'Skins/skaterFemaleA.png'],
  anims:{idle:K+'Animations/idle.fbx',run:K+'Animations/run.fbx',jump:K+'Animations/jump.fbx'},height:1.8,yawOffset:0,walkScale:.55},
 {format:'glb',model:'./models/characters/soldier.glb',height:1.8,yawOffset:0}
];
const note=m=>{try{window.__bzNote&&window.__bzNote('[models] '+m)}catch(e){}};
let tpl=null,state='idle',cfg=null,skinTex=[];
const entries=[];                       // everything currently animated
const hash=s=>{s=String(s);let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h};

/* ---------- loading ---------- */
const loadFBX=u=>new Promise((ok,no)=>new THREE.FBXLoader().load(u,ok,undefined,()=>no(new Error('cannot load '+u))));
const loadGLB=u=>new Promise((ok,no)=>new THREE.GLTFLoader().load(u,ok,undefined,()=>no(new Error('cannot load '+u))));
const loadTex=u=>new Promise((ok,no)=>new THREE.TextureLoader().load(u,t=>{t.encoding=THREE.sRGBEncoding;ok(t)},undefined,()=>no(new Error('cannot load '+u))));
/* FBX files from Kenney hold two stacks: a static "Targeting Pose" first, the real motion second. */
function bestClip(list,key){
  const c=(list||[]).filter(x=>!/target|t-?pose/i.test(x.name));
  return c.find(x=>new RegExp(key,'i').test(x.name))||c.sort((a,b)=>b.duration-a.duration)[0]||null;
}
function finish(root,clips,c){
  root.updateMatrixWorld&&root.updateMatrixWorld(true);
  const box=new THREE.Box3().setFromObject(root),size=new THREE.Vector3();box.getSize(size);
  if(!isFinite(size.y)||size.y<=.01)throw new Error('model has no measurable height');
  const k=(c.height||1.8)/size.y,holder=new THREE.Group();
  root.scale.multiplyScalar(k);root.position.y=-box.min.y*k;holder.add(root);holder.rotation.y=c.yawOffset||0;
  root.traverse(o=>{if(o.isMesh)o.frustumCulled=false});
  tpl={holder,clips,walkScale:c.walkScale||.55};
}
async function tryConfig(c){
  if(c.format==='fbx'){
    if(!THREE.FBXLoader||!window.fflate)throw new Error('FBXLoader/fflate missing');
    const root=await loadFBX(c.model),clips={};
    const skins=c.skins||(c.skin?[c.skin]:[]);skinTex=[];
    for(const s of skins){try{skinTex.push(await loadTex(s))}catch(e){note('skin missing: '+s)}}
    for(const key in (c.anims||{})){try{const a=await loadFBX(c.anims[key]);const cl=bestClip(a.animations,key);if(cl){cl.name=key;clips[key]=cl}}catch(e){note('animation '+key+' unavailable')}}
    if(!clips.idle){const own=bestClip(root.animations,'idle');if(own)clips.idle=own}
    finish(root,clips,c);
  }else{
    if(!THREE.GLTFLoader)throw new Error('GLTFLoader missing');
    const g=await loadGLB(c.model),l=g.animations||[];skinTex=[];
    finish(g.scene,{idle:bestClip(l,'idle|stand|rest'),run:bestClip(l,'run|sprint|jog'),walk:bestClip(l,'walk'),jump:bestClip(l,'jump')},c);
  }
}
async function load(){
  if(state!=='idle')return;state='loading';
  if(!THREE.SkeletonUtils){state='failed';note('SkeletonUtils missing - procedural characters');return}
  const list=[];
  try{const r=await fetch('./models/characters/manifest.json');if(r.ok){const m=await r.json();list.push(Object.assign({format:/\.fbx$/i.test(m.model)?'fbx':'glb'},m))}}catch(e){}
  DEFAULTS.forEach(d=>list.push(d));
  for(const c of list){try{await tryConfig(c);cfg=c;state='ready';note('ready: '+c.model+' clips='+Object.keys(tpl.clips).join(',')+' skins='+skinTex.length);return}catch(e){note(c.model+' skipped: '+e.message)}}
  state='failed';note('no character model usable - procedural characters stay');
}

/* ---------- instances ---------- */
function instance(skinKey){
  const model=THREE.SkeletonUtils.clone(tpl.holder);
  const tex=skinTex.length?skinTex[hash(skinKey)%skinTex.length]:null;
  model.traverse(o=>{
    o.userData.bzShared=true;                       // never dispose (shared geometry)
    if(tex&&o.isMesh)o.material=new THREE.MeshLambertMaterial({map:tex,skinning:!!o.isSkinnedMesh});
  });
  return model;
}
function animator(model){
  const any=tpl.clips.idle||tpl.clips.run||tpl.clips.walk;if(!any)return null;
  const mixer=new THREE.AnimationMixer(model),act=c=>c?mixer.clipAction(c):null,a={};
  const idle=act(tpl.clips.idle)||act(any),run=act(tpl.clips.run)||idle,walk=act(tpl.clips.walk),jump=act(tpl.clips.jump);
  a.idle={a:idle,ts:1};a.run={a:run,ts:1};
  a.walk=walk?{a:walk,ts:1}:{a:run,ts:(tpl.clips.run?tpl.walkScale:1)};   // no walk clip: slowed run
  a.jump=jump?{a:jump,ts:1}:null;
  return{mixer,acts:a,cur:null};
}
const lock=(o,v)=>{try{Object.defineProperty(o,'visible',{get:()=>v,set(){},configurable:true})}catch(e){}};
function register(obj,model,opt){
  const an=animator(model);if(an){an.cur=an.acts.idle;an.cur.a.play()}
  entries.push({obj,model,an,lx:obj.position.x,lz:obj.position.z,air:opt.air||null,far:!!opt.cull,speedOf:opt.speedOf||null});
}

/* Replace a procedural character group (local player root or bot group) by the model. Hit-boxes keep working
 * (they are still raycast; only their rendering is switched off). keep = objects that must stay visible. */
function dress(group,opt){
  opt=opt||{};const keep=new Set((opt.keep||[]).filter(Boolean)),show=new Set((opt.show||[]).filter(Boolean));
  const old=group.children.slice();
  const model=instance(opt.skinKey||group.uuid||'x');
  old.forEach(ch=>{if(keep.has(ch))return;lock(ch,show.has(ch))});
  group.add(model);register(group,model,opt);group.userData.bzDressed=true;
  if(opt.gun){const g=new THREE.Mesh(new THREE.BoxGeometry(.07,.11,.7),new THREE.MeshLambertMaterial({color:0x1a1d21}));g.position.set(.28,1.12,.42);g.userData.bzShared=false;group.add(g)}
}
/* Remote LAN player / bot avatar on another phone. */
function attach(id,a){
  const model=instance(id);a.group.add(model);a.model=model;
  [a.body,a.head].forEach(m=>{if(m&&m.material)m.material.visible=false}); // invisible hit-boxes; the held gun mesh stays visible
  const marker=new THREE.Mesh(new THREE.ConeGeometry(.12,.28,6),new THREE.MeshBasicMaterial({color:0xc84d43}));
  marker.rotation.x=Math.PI;marker.position.y=2.25;a.group.add(marker);
  register(a.group,model,{cull:true});
  entries[entries.length-1].marker=marker;entries[entries.length-1].avatar=a;entries[entries.length-1].id=id;
}

/* ---------- per-frame ---------- */
let last=performance.now();
function pickAct(e,sp){
  const a=e.an.acts;
  if(e.air&&a.jump&&e.air())return a.jump;
  return sp<.5?a.idle:sp>5.5?a.run:(sp>2.2?a.run:a.walk||a.run);
}
function tick(n){
  requestAnimationFrame(tick);
  const dt=Math.min((n-last)/1000,.1);last=n;
  if(state==='idle'&&((window.bzRemotePlayers&&window.bzRemotePlayers.size)||window.pmS||(typeof bots!=='undefined'&&bots.length)))load();
  if(state==='ready'){
    try{
      if(window.pmS&&!window.pmS.root.userData.bzDressed){
        const nm=(typeof bzSelectedCharacter==='function'&&bzSelectedCharacter().name)||'Recruit';
        dress(window.pmS.root,{skinKey:nm,gun:true,keep:[typeof bzVfxRoot!=='undefined'?bzVfxRoot:null],
          air:()=>typeof P!=='undefined'&&!P.air&&Math.abs(P.vy)>2.2});
      }
      if(typeof bots!=='undefined'&&typeof LQ!=='undefined'&&!LQ){
        bots.concat(typeof al!=='undefined'?al:[]).forEach((g,i)=>{if(g.userData&&!g.userData.bzDressed&&g.children.length&&!g.userData.retired){
          g.userData.bzDressed=true;
          const gun=g.children[3];                      // the held-gun box stays visible
          dress(g,{skinKey:(g.userData.nid||'bot')+i,show:[gun],cull:true});}});
      }
      const map=window.bzRemotePlayers;
      if(map)map.forEach((a,id)=>{if(!a.model&&a.group)try{attach(id,a)}catch(e){note('attach failed: '+e.message);a.model=true}});
    }catch(e){note('dress failed: '+e.message)}
  }
  const camP=(typeof cam!=='undefined'&&cam.position)?cam.position:null;
  for(let i=entries.length-1;i>=0;i--){
    const e=entries[i];
    if(e.avatar&&!(window.bzRemotePlayers&&window.bzRemotePlayers.get(e.id)===e.avatar)){ // avatar removed
      if(e.an)e.an.mixer.stopAllAction();entries.splice(i,1);continue}
    const p=e.obj.position,sp=Math.hypot(p.x-e.lx,p.z-e.lz)/Math.max(dt,.001);e.lx=p.x;e.lz=p.z;
    if(e.far&&camP){const dx=p.x-camP.x,dz=p.z-camP.z;if(dx*dx+dz*dz>8100){e.model.visible=false;continue}e.model.visible=true} // >90 m: skip
    if(e.an){
      const want=pickAct(e,sp);
      if(want&&want!==e.an.cur){
        if(want.a!==e.an.cur.a){want.a.reset().play();e.an.cur.a.crossFadeTo(want.a,.2,false)}
        want.a.setEffectiveTimeScale(want.ts);e.an.cur=want}
      e.an.mixer.update(dt)}
    if(e.marker&&e.avatar&&e.avatar.body&&e.avatar.body.material&&e.avatar.body.material.color)e.marker.material.color.copy(e.avatar.body.material.color);
  }
}
requestAnimationFrame(tick);
window.BZModels={status:()=>state,config:()=>cfg,count:()=>entries.length,dress,load};
})();
