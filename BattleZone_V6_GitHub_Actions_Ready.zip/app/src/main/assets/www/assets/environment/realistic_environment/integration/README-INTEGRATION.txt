BATTLE ZONE V6 — REALISTIC-STYLE TEXTURE INTEGRATION

1. Back up your project first.
2. Copy assets/textures into:
   app/src/main/assets/www/assets/environment/textures/
   Adjust the path if your project has a different asset root.
3. In the existing terrain/building material code, use the included JavaScript example.
4. Apply grass to terrain, dirt to paths, asphalt to roads, rock to boulders/cliffs, and concrete to building surfaces.
5. Keep texture repeats appropriate to mesh scale. Too few repeats can make terrain look blurry; too many can look noisy.
6. Test on a real Android device. These are 512x512 JPEG textures plus normal maps for low memory use.
7. This pack does not include 3D trees, buildings, foliage meshes, a sky HDRI, weather effects, or collision fixes.
8. If your Three.js version does not support MeshStandardMaterial or normal maps as configured, adapt to the bundled version.

These are procedural realistic-style materials made specifically for this ZIP, not photographs or unmodified third-party textures. They are provided without third-party restrictions. For true scanned photographic PBR assets, see licenses/ASSET_SOURCES.txt.
