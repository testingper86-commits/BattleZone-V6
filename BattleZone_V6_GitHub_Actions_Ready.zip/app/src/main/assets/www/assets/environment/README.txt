# Battle Zone — Compact Offline Environment Starter Pack

Target: Three.js game bundled inside an Android APK
Size target: under 10 MB compressed
Style: optimized realistic starter materials

## Contents
- `assets/textures/terrain_grass_512.jpg`
- `assets/textures/terrain_dirt_512.jpg`
- `assets/textures/terrain_rock_512.jpg`
- `assets/textures/terrain_asphalt_512.jpg`
  These four 512×512 seamless-style starter textures were procedurally authored for this pack. They are not third-party downloads and have no third-party license restrictions.
- `integration/threejs-material-example.js`: example material loader for classic Three.js.
- `integration/README-INTEGRATION.txt`: integration steps and compatibility notes.
- `licenses/ASSET_SOURCES.txt`: open-source asset sources to download separately.

## Honest scope
This ZIP contains the four texture image files and integration notes. It does NOT contain downloaded third-party GLB models. An attempt to fetch a CC0 GLB model failed because this environment could not resolve external download hosts. The listed source links are provided so models can be downloaded separately when network access is available.

## Important
This is a starter asset pack, not a completed map upgrade. It will not automatically replace terrain or add buildings/trees. Your game code must load and assign these textures. Back up your project before integration.
