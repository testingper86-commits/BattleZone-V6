// Example for classic Three.js. Adapt paths to your Android project's actual assets folder.
// Example path if copied to app/src/main/assets/www/assets/environment/textures/
const textureLoader = new THREE.TextureLoader();

function loadTiledMaterial(path, repeatX = 8, repeatY = 8) {
  const texture = textureLoader.load(path);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeatX, repeatY);
  texture.colorSpace = THREE.SRGBColorSpace; // For modern Three.js versions.
  return new THREE.MeshStandardMaterial({
    map: texture,
    roughness: 1.0,
    metalness: 0.0
  });
}

const grassMaterial = loadTiledMaterial(
  'assets/environment/textures/terrain_grass_512.jpg', 12, 12
);
const dirtMaterial = loadTiledMaterial(
  'assets/environment/textures/terrain_dirt_512.jpg', 10, 10
);
const rockMaterial = loadTiledMaterial(
  'assets/environment/textures/terrain_rock_512.jpg', 6, 6
);
const asphaltMaterial = loadTiledMaterial(
  'assets/environment/textures/terrain_asphalt_512.jpg', 8, 8
);

// Assign the chosen material to your existing terrain/road meshes.
// Do not add a second ground plane over your existing terrain.
// Older Three.js versions may use texture.encoding = THREE.sRGBEncoding instead
// of texture.colorSpace. Check the version bundled in your project.
