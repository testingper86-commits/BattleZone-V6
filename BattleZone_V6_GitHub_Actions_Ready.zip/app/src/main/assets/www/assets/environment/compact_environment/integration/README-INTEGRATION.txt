INTEGRATION NOTES — Battle Zone V6

1. Back up the existing project.
2. Copy the `assets/textures` folder into:
   app/src/main/assets/www/assets/environment/textures/
   (Create the folders if needed; adapt if your project uses another asset root.)
3. Open your existing Three.js terrain/road creation code.
4. Load one of the provided textures and assign the material to the existing mesh.
5. Keep texture repeats modest and avoid creating duplicate terrain meshes.
6. Test on a physical Android device; 512x512 JPG textures are intentionally small.
7. If the game uses an older Three.js build, adjust the color-space property as noted in the JS example.
8. This pack does not include GLB models, collision meshes, sky/HDRI, or weather code.
