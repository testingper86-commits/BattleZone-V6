BATTLE ZONE — REALISTIC-STYLE OFFLINE ENVIRONMENT TEXTURE PACK

Target: Three.js Android APK, offline
Compressed ZIP target: under 10 MB
Contents:
- 5 512x512 ground/building color textures: grass, dirt, rock, asphalt, concrete
- 5 matching lightweight normal maps
- Three.js local texture loading example
- Android integration notes
- CC0 source links for true photographic PBR textures

Honesty note:
This ZIP contains locally authored procedural realistic-style textures. It does not contain external Poly Haven/ambientCG downloads or 3D environment models. Direct download attempts from source hosts failed in this build session. Use the source links in licenses/ASSET_SOURCES.txt to obtain photographic assets separately.

This is a texture starter pack, not a complete environment/map upgrade. Your existing game code must load and assign the textures. Back up the project before integration.
