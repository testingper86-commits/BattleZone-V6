// Three.js classic build example for locally bundled textures.
// Copy assets/textures to app/src/main/assets/www/assets/environment/textures/
// Use only with the version of Three.js already bundled in your game.
const envTextureLoader = new THREE.TextureLoader();

function loadEnvironmentMaterial(name, repeatX = 8, repeatY = 8) {
  const map = envTextureLoader.load(`assets/environment/textures/${name}_color.jpg`);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(repeatX, repeatY);
  if ('colorSpace' in map && THREE.SRGBColorSpace) map.colorSpace = THREE.SRGBColorSpace;
  else if ('encoding' in map && THREE.sRGBEncoding) map.encoding = THREE.sRGBEncoding;

  const normalMap = envTextureLoader.load(`assets/environment/textures/${name}_normal.jpg`);
  normalMap.wrapS = THREE.RepeatWrapping;
  normalMap.wrapT = THREE.RepeatWrapping;
  normalMap.repeat.set(repeatX, repeatY);

  return new THREE.MeshStandardMaterial({
    map,
    normalMap,
    roughness: 0.94,
    metalness: 0.0
  });
}

const grassMaterial = loadEnvironmentMaterial('grass', 12, 12);
const dirtMaterial = loadEnvironmentMaterial('dirt', 10, 10);
const rockMaterial = loadEnvironmentMaterial('rock', 6, 6);
const asphaltMaterial = loadEnvironmentMaterial('asphalt', 8, 8);
const concreteMaterial = loadEnvironmentMaterial('concrete', 6, 6);

// Assign to existing meshes only; do not create duplicate ground planes.
// If normals look inverted, confirm your Three.js normal-map convention.
