three.min.js (Three.js r128, classic build) is downloaded automatically by the Gradle task
"downloadThreeJs" on every build (see app/build.gradle.kts). Nothing to do by hand.
Manual alternative: python download_threejs.py   (run from the project root)
Do NOT use three.module.js or a newer release renamed to three.min.js.
The game does not use FBXLoader/GLTFLoader: all characters are built procedurally in code.
