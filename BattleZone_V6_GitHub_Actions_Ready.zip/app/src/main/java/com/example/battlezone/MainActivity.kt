package com.example.battlezone

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.ApplicationInfo
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.*
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private val io = Executors.newCachedThreadPool()
    private val clients = ConcurrentHashMap<String, Peer>()
    private val playerCounter = AtomicInteger(1)
    @Volatile private var server: ServerSocket? = null
    @Volatile private var hostMode = false
    @Volatile private var running = true
    // Incremented by every stopNetwork(); background loops exit when their captured value goes stale,
    // so a quick re-host cannot resurrect threads from the previous session.
    @Volatile private var session = 0
    @Volatile private var roomId = ""
    @Volatile private var roomName = "Battle Zone Room"
    @Volatile private var roomPasswordHash = ""
    @Volatile private var roomMode = "tdm"
    @Volatile private var maxPlayers = 8
    @Volatile private var hostIp = ""
    private val roomPort = 42424
    private val discoveryPort = 42425
    private val peers = ConcurrentHashMap<String, Peer>()
    private val relayKinds = setOf("player-state", "combat")

    private data class Peer(val id: String, val socket: Socket, val writer: PrintWriter, val name: String)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        applyImmersive()
        // Lets you inspect the game with chrome://inspect on debug builds (shows JS errors/WebGL state).
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true)
        assetLoader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            addJavascriptInterface(GameNetworkBridge(), "BattleNetwork")
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                    val line = "${m.message()} -- ${m.sourceId()?.substringAfterLast('/')}:${m.lineNumber()}"
                    when (m.messageLevel()) {
                        ConsoleMessage.MessageLevel.ERROR -> android.util.Log.e("BattleZoneWeb", line)
                        ConsoleMessage.MessageLevel.WARNING -> android.util.Log.w("BattleZoneWeb", line)
                        else -> android.util.Log.d("BattleZoneWeb", line)
                    }
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val response = assetLoader.shouldInterceptRequest(request.url) ?: return null
                    // Guarantee correct MIME types (the default guesser can return text/plain for some types).
                    val path = request.url.path ?: ""
                    val mime = when (path.substringAfterLast('.', "").lowercase()) {
                        "js" -> "text/javascript"; "mjs" -> "text/javascript"; "json" -> "application/json"
                        "mp3" -> "audio/mpeg"; "ogg" -> "audio/ogg"; "wav" -> "audio/wav"
                        "glb" -> "model/gltf-binary"; "gltf" -> "model/gltf+json"; "fbx" -> "application/octet-stream"
                        "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "webp" -> "image/webp"
                        "html" -> "text/html"; "css" -> "text/css"
                        else -> null
                    }
                    if (mime != null) response.mimeType = mime
                    return response
                }
                // Keep the JS bridge confined to the bundled game: never navigate the WebView elsewhere.
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.host != "appassets.androidplatform.net"
                override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                    android.util.Log.w("BattleZoneWeb", "HTTP ${errorResponse.statusCode} for ${request.url}")
                }
                // If Android kills the WebView renderer (low memory / GPU reset) restart cleanly instead of a black screen.
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    android.util.Log.e("BattleZoneWeb", "Renderer process gone (crashed=${detail.didCrash()}); recreating")
                    runOnUiThread { recreate() }
                    return true
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }
    // Sticky immersive mode is dropped whenever focus is lost (dialogs, notification shade); restore it.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }
    // Stop game timers/audio/rendering while the app is in the background.
    override fun onPause() { if (::webView.isInitialized) webView.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (::webView.isInitialized) webView.onResume() }

    private fun emit(type: String, payload: JSONObject = JSONObject()) {
        val event = JSONObject().put("type", type).put("payload", payload)
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('battle-network', {detail:${JSONObject.quote(event.toString())}}));", null) }
    }
    private fun status(state: String, extra: JSONObject = JSONObject()) { emit("status", extra.put("state", state)) }
    private fun sameHash(a: String, b: String): Boolean = MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    private fun localIp(): String {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val n = wm.connectionInfo.ipAddress
            if (n != 0) return "%d.%d.%d.%d".format(n and 255, n shr 8 and 255, n shr 16 and 255, n shr 24 and 255)
        } catch (_: Exception) {}
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            val lan = ifaces.sortedBy { if (Regex("^(wlan|ap|swlan|eth)").containsMatchIn(it.name)) 0 else 1 }
            return lan.flatMap { it.inetAddresses.toList() }.first { !it.isLoopbackAddress && it is Inet4Address }.hostAddress ?: ""
        } catch (_: Exception) {}
        return ""
    }

    inner class GameNetworkBridge {
        @JavascriptInterface fun hostRoom(name: String, password: String, mode: String, maxText: String) {
            io.execute {
                try {
                    stopNetwork(); hostMode = true; running = true
                    val mySession = session
                    roomId = UUID.randomUUID().toString().take(8).uppercase()
                    roomName = name.trim().take(28).ifBlank { "Battle Zone Room" }
                    roomPasswordHash = sha256(password)
                    roomMode = if (mode == "ffa") "ffa" else "tdm"
                    maxPlayers = maxText.toIntOrNull()?.coerceIn(2, 8) ?: 8
                    hostIp = localIp()
                    server = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress("0.0.0.0", roomPort), 16) }
                    android.util.Log.i("BattleZoneNet", "TCP room host listening on $roomPort; localIp=$hostIp roomId=$roomId")
                    startDiscoveryResponder(mySession)
                    status("hosting", JSONObject().put("roomId", roomId).put("roomName", roomName).put("address", hostIp).put("port", roomPort).put("mode", roomMode).put("maxPlayers", maxPlayers).put("players", 1))
                    while (running && hostMode && session == mySession) {
                        val s = server?.accept() ?: break
                        s.soTimeout = 10000
                        io.execute { handleNewPeer(s) }
                    }
                } catch (e: Exception) { android.util.Log.e("BattleZoneNet", "Could not host room", e); if (running) status("error", JSONObject().put("message", e.message ?: "Could not host room")) }
            }
        }
        @JavascriptInterface fun discoverRooms() {
            io.execute {
                val found = ConcurrentHashMap<String, JSONObject>()
                var sock: DatagramSocket? = null
                var multicast: WifiManager.MulticastLock? = null
                try {
                    val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    multicast = wifi.createMulticastLock("BattleZoneDiscovery").apply { setReferenceCounted(false); acquire() }

                    // Bind to the same UDP port that hosts listen on. This lets the scanner receive
                    // both direct replies and periodic room announcements sent to port 42425.
                    sock = DatagramSocket(null).apply {
                        reuseAddress = true
                        broadcast = true
                        bind(InetSocketAddress("0.0.0.0", discoveryPort))
                        soTimeout = 350
                    }
                    val req = "BZ_DISCOVER_V1".toByteArray(Charsets.UTF_8)
                    val targets = discoveryBroadcastAddresses()
                    android.util.Log.i("BattleZoneNet", "Discovery targets=$targets port=$discoveryPort")

                    // Send multiple rounds because Android hotspot/router power-save can drop UDP broadcasts.
                    repeat(4) { round ->
                        targets.forEach { target ->
                            try {
                                sock.send(DatagramPacket(req, req.size, target, discoveryPort))
                                android.util.Log.d("BattleZoneNet", "Discovery probe sent to $target:$discoveryPort round=$round")
                            } catch (e: Exception) {
                                android.util.Log.w("BattleZoneNet", "Probe failed for $target", e)
                            }
                        }
                        Thread.sleep(180)
                    }

                    val until = System.currentTimeMillis() + 3200
                    val buf = ByteArray(4096)
                    while (System.currentTimeMillis() < until) {
                        try {
                            val packet = DatagramPacket(buf, buf.size)
                            sock.receive(packet)
                            val text = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                            if (text.startsWith("BZ_ROOM_V1|")) {
                                val o = JSONObject(text.substringAfter('|'))
                                o.put("address", packet.address.hostAddress)
                                found[o.optString("roomId")] = o
                                android.util.Log.i("BattleZoneNet", "Room discovered id=${o.optString("roomId")} from=${packet.address.hostAddress}")
                            }
                        } catch (_: SocketTimeoutException) {
                            // Continue until the complete scan window expires.
                        }
                    }
                    val arr = JSONArray()
                    found.values.forEach { arr.put(it) }
                    emit("rooms", JSONObject().put("rooms", arr))
                    status("discovery-complete", JSONObject().put("count", arr.length()).put("targets", targets.size))
                    android.util.Log.i("BattleZoneNet", "Discovery finished count=${arr.length()}")
                } catch (e: Exception) {
                    android.util.Log.e("BattleZoneNet", "Room discovery failed", e)
                    status("error", JSONObject().put("message", e.message ?: "Room discovery failed"))
                } finally {
                    sock?.close()
                    try { multicast?.release() } catch (_: Exception) {}
                }
            }
        }
        @JavascriptInterface fun joinRoom(address: String, portText: String, id: String, password: String, playerName: String) {
            io.execute {
                var socket: Socket? = null
                try {
                    stopNetwork(); running = true; hostMode = false
                    val ip = address.trim(); require(ip.matches(Regex("[A-Za-z0-9.:-]{1,100}"))) { "Invalid room address" }
                    val port = portText.toIntOrNull() ?: roomPort; require(port in 1..65535)
                    val sock = Socket().also { socket = it }; sock.connect(InetSocketAddress(ip, port), 5000); sock.soTimeout = 10000
                    val out = PrintWriter(sock.getOutputStream(), true)
                    val input = BufferedReader(InputStreamReader(sock.getInputStream()))
                    out.println(JSONObject().put("kind", "hello").put("protocol", 1).put("roomId", id).put("password", password).put("name", playerName.take(20).ifBlank { "Player" }))
                    val response = input.readLine() ?: throw IllegalStateException("Host closed connection")
                    val welcome = JSONObject(response)
                    if (!welcome.optBoolean("ok")) throw IllegalStateException(welcome.optString("error", "Room join rejected"))
                    sock.soTimeout = 0
                    val peer = Peer(welcome.optString("playerId", "P"), sock, out, playerName)
                    peers[peer.id] = peer
                    status("connected", JSONObject().put("transport", "wifi").put("playerId", peer.id).put("roomId", welcome.optString("roomId")).put("roomName", welcome.optString("roomName")).put("mode", welcome.optString("mode", "tdm")).put("maxPlayers", welcome.optInt("maxPlayers", 8)).put("players", welcome.optInt("players")))
                    readClientLoop(input, peer)
                } catch (e: Exception) {
                    try { socket?.close() } catch (_: Exception) {}
                    status("error", JSONObject().put("message", e.message ?: "Could not join room"))
                }
            }
        }
        @JavascriptInterface fun send(message: String) {
            if (message.length > 8192) return
            try {
                val obj = JSONObject(message)
                if (hostMode) { obj.put("senderId", "HOST"); broadcast(obj, null) }
                else peers.values.firstOrNull()?.let { synchronized(it.writer) { it.writer.println(obj.toString()) } }
            } catch (_: Exception) {}
        }
        @JavascriptInterface fun disconnect() { stopNetwork(); status("disconnected") }
    }

    private fun handleNewPeer(socket: Socket) {
        var peer: Peer? = null
        try {
            val input = BufferedReader(InputStreamReader(socket.getInputStream()))
            val out = PrintWriter(socket.getOutputStream(), true)
            val line = input.readLine() ?: throw IllegalStateException("Missing room handshake")
            if (line.length > 4096) throw IllegalStateException("Handshake too large")
            val hello = JSONObject(line)
            if (hello.optInt("protocol") != 1 || hello.optString("roomId") != roomId) { out.println(JSONObject().put("ok", false).put("error", "Room code or protocol mismatch")); socket.close(); return }
            if (!sameHash(sha256(hello.optString("password")), roomPasswordHash)) { out.println(JSONObject().put("ok", false).put("error", "Incorrect room password")); socket.close(); return }
            if (clients.size + 1 >= maxPlayers) { out.println(JSONObject().put("ok", false).put("error", "Room is full")); socket.close(); return }
            socket.soTimeout = 0
            val id = "P${playerCounter.getAndIncrement()}"
            peer = Peer(id, socket, out, hello.optString("name", "Player").take(20))
            clients[id] = peer
            out.println(JSONObject().put("ok", true).put("playerId", id).put("roomId", roomId).put("roomName", roomName).put("mode", roomMode).put("maxPlayers", maxPlayers).put("players", clients.size + 1))
            broadcast(JSONObject().put("kind", "peer-joined").put("playerId", id).put("name", peer.name).put("players", clients.size + 1), id)
            status("player-joined", JSONObject().put("playerId", id).put("name", peer.name).put("players", clients.size + 1))
            while (running && !socket.isClosed) {
                val msg = input.readLine() ?: break
                if (msg.length > 8192) continue
                val obj = try { JSONObject(msg) } catch (_: Exception) { continue }
                if (obj.optString("kind") !in relayKinds) continue
                obj.put("senderId", id)
                broadcast(obj, id)
                emit("message", obj)
            }
        } catch (_: Exception) {
        } finally {
            if (peer != null) {
                clients.remove(peer.id)
                broadcast(JSONObject().put("kind", "peer-left").put("playerId", peer.id).put("players", clients.size + 1), peer.id)
                status("player-left", JSONObject().put("playerId", peer.id).put("players", clients.size + 1))
            }
            try { socket.close() } catch (_: Exception) {}
        }
    }
    private fun readClientLoop(input: BufferedReader, peer: Peer) {
        try {
            while (running && !peer.socket.isClosed) {
                val line = input.readLine() ?: break
                if (line.length > 8192) continue
                val obj = try { JSONObject(line) } catch (_: Exception) { continue }
                emit("message", obj)
            }
        } catch (_: Exception) {} finally { peers.remove(peer.id); try { peer.socket.close() } catch (_: Exception) {}; status("peer-disconnected") }
    }
    private fun broadcast(obj: JSONObject, except: String?) {
        val line = obj.toString()
        clients.values.forEach { p -> if (p.id != except) try { synchronized(p.writer) { p.writer.println(line) }; if (p.writer.checkError()) clients.remove(p.id) } catch (_: Exception) { clients.remove(p.id) } }
    }
    /** IPv4 broadcast destinations for the active LAN interfaces plus safe fallbacks. */
    private fun discoveryBroadcastAddresses(): List<InetAddress> {
        val result = LinkedHashSet<InetAddress>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                try {
                    for (entry in networkInterface.interfaceAddresses) {
                        val address = entry.address
                        val broadcast = entry.broadcast
                        if (address is Inet4Address && !address.isLoopbackAddress && broadcast != null) {
                            result.add(broadcast)
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.d("BattleZoneNet", "Could not inspect interface ${networkInterface.name}", e)
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("BattleZoneNet", "Interface broadcast enumeration failed", e)
        }
        listOf("255.255.255.255", "192.168.43.255", "192.168.137.255", "192.168.1.255", "192.168.0.255").forEach {
            try { result.add(InetAddress.getByName(it)) } catch (_: Exception) {}
        }
        return result.toList()
    }

    private fun startDiscoveryResponder(mySession: Int) {
        io.execute {
            var ds: DatagramSocket? = null
            try {
                ds = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress("0.0.0.0", discoveryPort))
                }
                android.util.Log.i("BattleZoneNet", "Discovery responder listening on UDP $discoveryPort")
                val buf = ByteArray(1024)
                while (running && hostMode && session == mySession) {
                    try {
                        val packet = DatagramPacket(buf, buf.size)
                        ds.receive(packet)
                        val request = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                        if (request == "BZ_DISCOVER_V1") {
                            android.util.Log.d("BattleZoneNet", "Discovery request from ${packet.address.hostAddress}:${packet.port}")
                            sendRoomAnnouncement(ds, packet.address, packet.port)
                        }
                    } catch (_: SocketException) {
                        break
                    } catch (e: Exception) {
                        android.util.Log.w("BattleZoneNet", "Discovery responder packet error", e)
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("BattleZoneNet", "Could not start discovery responder on UDP $discoveryPort", e)
                if (running && hostMode) status("error", JSONObject().put("message", "Room discovery listener failed: ${e.message ?: "UDP bind error"}"))
            } finally {
                ds?.close()
            }
        }
        io.execute {
            var ds: DatagramSocket? = null
            try {
                ds = DatagramSocket().apply { broadcast = true }
                while (running && hostMode && session == mySession) {
                    discoveryBroadcastAddresses().forEach { address ->
                        try { sendRoomAnnouncement(ds, address, discoveryPort) }
                        catch (e: Exception) { android.util.Log.d("BattleZoneNet", "Periodic announcement failed to $address", e) }
                    }
                    Thread.sleep(1600)
                }
            } catch (e: Exception) {
                if (running && hostMode) android.util.Log.w("BattleZoneNet", "Periodic discovery announcements stopped", e)
            } finally {
                ds?.close()
            }
        }
    }
    private fun sendRoomAnnouncement(ds: DatagramSocket, address: InetAddress, port: Int = discoveryPort) {
        try {
            val data = ("BZ_ROOM_V1|" + JSONObject().put("roomId", roomId).put("roomName", roomName).put("port", roomPort).put("mode", roomMode).put("players", clients.size + 1).put("maxPlayers", maxPlayers).toString()).toByteArray()
            ds.send(DatagramPacket(data, data.size, address, port))
        } catch (_: Exception) {}
    }
    @Synchronized private fun stopNetwork() {
        running = false; hostMode = false; session++
        try { server?.close() } catch (_: Exception) {}; server = null
        clients.values.forEach { try { it.socket.close() } catch (_: Exception) {} }; clients.clear()
        peers.values.forEach { try { it.socket.close() } catch (_: Exception) {} }; peers.clear()
        roomId = ""
    }
    override fun onDestroy() {
        stopNetwork(); io.shutdownNow()
        if (::webView.isInitialized) { webView.removeJavascriptInterface("BattleNetwork"); webView.stopLoading(); webView.destroy() }
        super.onDestroy()
    }
}
