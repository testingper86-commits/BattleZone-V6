@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 setup_assets.py
) else (
  python setup_assets.py
)
if errorlevel 1 (
  echo.
  echo REQUIRED ASSETS COULD NOT BE DOWNLOADED. Check internet access and run this again.
  pause
  exit /b 1
)
if exist gradlew.bat (
  call gradlew.bat :app:assembleDebug
) else (
  echo Gradle wrapper script is not included. Open this folder in Android Studio and build app:assembleDebug.
  pause
  exit /b 2
)
endlocal
