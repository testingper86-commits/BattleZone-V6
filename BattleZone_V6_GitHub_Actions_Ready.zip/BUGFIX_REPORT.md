# Bug-fix report

Verified statically only (node syntax check, TypeScript name check, XML/Python parse). Not built with Gradle, not run on a device, and Three.js r128 is still absent from the package.

## Game (index.html)
1. START button crashed: `bzPlayEventVoice` lived inside a closure but was called from the global match-start, `killBot` and `end` code. This threw a ReferenceError, so `spawnBots()` and the plane flight never ran. Now exported on `window`.
2. "Match mode" and "Performance profile" buttons threw ReferenceError (`sheet` not in scope). Now `const sheet=window.sheetUI`.
3. A missing `three.min.js` produced a silent black screen. Now shows an explanatory message.
4. Joining a room ignored the discovered port (hard-coded 42424). Now uses the advertised port.
5. Remote avatars were never disposed (GPU memory leak on join/leave churn). Now disposed.

## Android (MainActivity.kt / manifest)
6. One malformed JSON line disconnected a peer (host and client loops). Now skipped.
7. Clients could forge `peer-joined` / `peer-left`. Host now relays only `player-state` and `combat`.
8. Stale discovery/accept threads could revive after a quick re-host. Added a session counter.
9. Join socket leaked on failure. Now closed. Handshake read has a 10 s timeout.
10. Password hash comparison is now constant-time.
11. Host IP detection prefers wlan/ap interfaces over cellular.
12. WebView can no longer navigate away from the bundled game (the JS bridge stays confined).
13. Added onPause/onResume (game kept running in background), immersive mode restored on focus, display-cutout support.
14. configChanges extended so foldables/multi-window resizes do not destroy the activity and network session.

## Scripts
15. `download_threejs.py` wrote to a cwd-relative path. Now project-relative.
16. `.bat` installers: added `cd /d "%~dp0"` (voice installer lacked it) and a `py -3` fallback.
17. Voice installer file order is now deterministic. `validate_project.py` exits non-zero on failed checks.

## Still open (not fixed)
- Three.js r128 must be downloaded (no network here).
- No Gradle wrapper is included; Android Studio will prompt to create one.
- Multiplayer is still a relay foundation: no authoritative hits/health/score (see NETWORK_PROTOCOL.md).
- Voice lookup tries the nonexistent `audio/open_source_voice/` first (3 harmless 404s).
- Downloaded GLB character models are not wired into the game.
