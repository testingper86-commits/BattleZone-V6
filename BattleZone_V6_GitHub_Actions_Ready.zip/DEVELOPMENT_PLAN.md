# Battle Zone Offline — Complete Upgrade Plan

## Product target
- Android landscape game built from the existing Three.js r128 HTML game.
- Offline single-player remains the default and must work without a network connection.
- Balanced realistic visuals for a broad range of Android devices.
- Local matches targeting up to 8 human players over Wi-Fi/LAN, with bots filling unused slots after authoritative gameplay sync is implemented.
- Modes: Team Deathmatch (TDM) and Free-for-All (FFA).

## Implementation phases

### Phase 0 — Protect the working game (first)
1. Keep a pristine copy of the original `battle-zone-new-ui-1.html` outside the edited project.
2. Confirm offline boot, touch controls, weapons, pickups, save data, pause/restart and existing solo/duo/squad modes.
3. Bundle Three.js r128 locally at `app/src/main/assets/www/libs/three.min.js`; remove runtime CDN dependency for offline use.
4. Build a debug APK and install it on at least one target phone before gameplay changes.

### Phase 1 — Multiplayer transport and lobby
1. Host accepts multiple peers, not just one; cap the room at 8 total humans.
2. Add room version, unique player IDs, heartbeat, disconnect cleanup, reconnect token and host migration policy (initial version: host leaves = match ends).
3. Lobby shows connection method, player list, ready state, selected mode and human/bot slots.
4. LAN discovery and Android Wi-Fi/hotspot behavior must be tested on real devices. All phones must share a LAN/hotspot.

### Phase 2 — Game-state protocol (required before playable multiplayer)
1. Host is authoritative for match clock, teams, spawn points, health, ammo, damage, kills, deaths and respawns.
2. Clients send input/intent, not trusted damage results.
3. Replicate position/rotation snapshots at a modest rate; interpolate remote avatars between snapshots.
4. Validate all incoming packets: schema/version, bounds, rate limits, player identity and message size.
5. Add hit confirmation, scoreboard and kill feed from host-approved events.

### Phase 3 — TDM and FFA
- FFA: each human and bot is an opponent; highest kills at match end wins.
- TDM: split players/bots into two teams; friendly fire off by default; score by team kills.
- Bots fill vacancies until the configured match population (maximum 8 total combatants, unless later performance tests justify a larger offline-only count).
- Bots use existing cover/flank/rush behaviors, but target selection must respect team membership in TDM.

### Phase 4 — Bot and combat integration
- Shared combat API for human and bot actors: spawn, fire intent, hit validation, damage, death, respawn and score.
- Bot decisions: cover, flank, investigate gunshots, heal, retreat and re-engage; difficulty adjusts reaction delay, accuracy and awareness, not impossible aim.
- Ensure offline matches use the same combat rules without requiring the Android bridge.

### Phase 5 — Visuals and performance
- Use the current realistic environment as the baseline; add visual effects incrementally.
- LOD/instancing for vegetation, pooling for bullets and particles, capped pixel ratio, reduced shadow distance and graphics presets.
- Low/Medium/High presets; disable expensive shadows/post effects on low preset.
- Target 30 FPS on entry-level supported phones and 60 FPS where devices can sustain it. Measure on hardware; do not assume from desktop results.

### Phase 6 — Release QA
- Test offline mode with airplane mode enabled.
- Test 2, 4 and 8 human slots; 1–7 humans with bot fill; TDM/FFA; Wi-Fi/hotspot discovery separately.
- Test late join, duplicate IDs, disconnect/reconnect, host shutdown, packet loss, rapid fire, death/respawn and match end.
- Test 30-minute sessions for memory growth, overheating and battery use.

## Acceptance criteria
- Existing offline game remains playable without an external game server or internet access; local networking permission is used only for LAN rooms.
- APK loads all core assets locally.
- Every connected player sees the same teams, health, deaths, kills, score and match end.
- No more than 8 total combatants are admitted to an 8-slot room.
- Bots fill empty slots and never target teammates in TDM.
- Graphics presets reduce workload without breaking controls or gameplay.
