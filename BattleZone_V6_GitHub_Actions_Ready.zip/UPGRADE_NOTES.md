# Battle Zone upgrade notes

## Included
- Existing Android Studio WebView wrapper retained.
- Existing HTML game controls, lobby, maps, weapons, vehicles, weather and persistence retained.
- Richer color response through Three.js r128 ACES filmic tone mapping and sRGB output.
- Layered procedural tree crowns; shadow casting follows the existing High/Low graphics choice.
- Enemy AI roles for cover-seeking, flanking, and rushing.
- Balanced mobile pixel ratio cap to reduce GPU load on high graphics.

## Before building
Confirm this file exists:
`app/src/main/assets/www/libs/three.min.js`

If missing, run this from the extracted project root in PowerShell:
`Invoke-WebRequest "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" -OutFile "app/src/main/assets/www/libs/three.min.js"`

The file is not included in this ZIP because the build environment cannot access the CDN. The game will not run correctly until it is present locally. Gradle sync/build may also require internet once.
