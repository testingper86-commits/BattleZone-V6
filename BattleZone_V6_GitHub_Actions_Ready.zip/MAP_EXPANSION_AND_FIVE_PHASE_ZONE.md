# Battle Zone — Map Expansion and Five-Phase Zone Update

## Map work included
- 900 × 900 world ground with a playable boundary at ±438 world units.
- Player, bots, allies, and vehicles are clamped inside the playable boundary.
- Terrain props, rocks, building candidates, and pickup placements are spread toward the outer parts of the larger world.
- Five named landmark areas: Military Base, Old Town, Industrial Yard, Forest Camp, and Central Outpost. These use simple generated geometry and are not hand-authored final art.
- Minimap world scale updated for the larger world.
- HUD map info reports the active zone phase, current radius, nearest landmark, and whether the player is inside the zone.

## Safe-zone work included
- Initial Battle Royale zone radius: 320 world units.
- Five target radius ratios: 70%, 50%, 32%, 16%, and 5% of the initial radius.
- Smooth eased zone center/radius transitions, phase waits, a final-zone state, and escalating outside-zone damage.
- The next circle is selected within the current safe circle so it remains nested.

## Still pending / limitations
- Landmark structures and terrain placement are procedural prototypes; visual review and balancing are still required.
- Loot distribution is spread over a larger area, but loot/building collision and spawn fairness require play-testing.
- No Android APK build or physical-device test was performed.
- Three.js r128 is still missing from `app/src/main/assets/www/libs/three.min.js`; the offline wrapper needs this local dependency.
- Multiplayer room discovery, password validation, and synchronized gameplay remain separate incomplete work; this update does not claim those features are complete.
