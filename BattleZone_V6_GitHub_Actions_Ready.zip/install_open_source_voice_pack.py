import os, re, urllib.request, zipfile, tempfile, shutil, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
WWW=ROOT/'app/src/main/assets/www'
URL='https://opengameart.org/sites/default/files/Voiceover%20Pack.zip'

def norm(s): return re.sub(r'[^a-z0-9]+','',s.lower())

def main():
    out=WWW/'audio'/'open_source_voice'
    out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        zpath=pathlib.Path(td)/'voiceover.zip'
        req=urllib.request.Request(URL,headers={'User-Agent':'BattleZone-Asset-Installer/1.0'})
        print('Downloading Kenney CC0 Voiceover Pack...')
        with urllib.request.urlopen(req,timeout=45) as r, open(zpath,'wb') as f: shutil.copyfileobj(r,f)
        with zipfile.ZipFile(zpath) as z:
            z.extractall(pathlib.Path(td)/'pack')
        files=sorted(p for p in (pathlib.Path(td)/'pack').rglob('*') if p.is_file() and p.suffix.lower() in ('.ogg','.wav','.mp3'))
        if not files: raise RuntimeError('No audio files found in downloaded pack.')
        # Find clips by title; fallback to stable sorted files if archive naming differs.
        def choose(words, fallback):
            for p in files:
                stem=norm(p.stem)
                if all(norm(w) in stem for w in words): return p
            for p in files:
                stem=norm(p.stem)
                if any(norm(w) in stem for w in words): return p
            return files[min(fallback,len(files)-1)]
        # Universal combat callouts: startup, reload/engage, victory. Female/male variants are alternated per operator.
        choices=[choose(['go'],0),choose(['reloading'],1),choose(['you','win'],2)]
        # Ensure distinct source clips if naming fallback caused duplicates.
        used=[]
        for i,p in enumerate(choices):
            if p in used: p=files[min(i+3,len(files)-1)]
            choices[i]=p; used.append(p)
        roster=['recruit','ranger','vanguard','phantom','ember_fox','frostline','wraith','solstice','aegis_legend','oracle','ironclad','storm_warden','titan_zero','neon_viper','redshift','nova_prime','void_monarch']
        manifest=[]
        for ri,name in enumerate(roster):
            for idx,src in enumerate(choices,1):
                # Keep original format so the extension matches the actual codec.
                dest=out/f'{name}_line_{idx}{src.suffix.lower()}'
                shutil.copy2(src,dest)
                manifest.append(f'{name},line_{idx},{src.name},{dest.name}')
        (out/'LICENSE.txt').write_text('Kenney Voiceover Pack by Kenney.nl. Creative Commons CC0 1.0 Universal. Attribution is not required; credit is appreciated. Source: https://kenney.nl/assets/voiceover-pack\n',encoding='utf-8')
        (out/'voice_manifest.csv').write_text('operator,line,source_file,installed_file\n'+'\n'.join(manifest)+'\n',encoding='utf-8')
    print(f'Installed open-source voice clips for {len(roster)} operators in {out}')

if __name__=='__main__':
    main()
