#!/usr/bin/env python3
"""Static validation for the Battle Zone Android/WebView source package.

Checks local asset references and JavaScript syntax. Requires Node.js for syntax checks.
This is not a substitute for an Android Gradle build or device test.
"""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'app/src/main/assets/www/index.html'
if not HTML.is_file():
    raise SystemExit(f'Missing game HTML: {HTML}')
source = HTML.read_text(encoding='utf-8')
checks = {
    'Battle Royale mode': "BZ_MODE==='BR'" in source,
    'Team Deathmatch mode': "BZ_MODE==='TDM'" in source,
    'Free-for-All mode': "BZ_MODE==='FFA'" in source,
    'mode selector UI': 'id="matchmode"' in source,
    'texture integration': 'const BZMaterial=' in source,
    'local Three.js script reference': 'src="./libs/three.min.js"' in source,
}
asset_dir = ROOT / 'app/src/main/assets/www'
checks['27 texture maps'] = len(list((asset_dir / 'textures').glob('*.png'))) >= 27
checks['5 effect sprites'] = len(list((asset_dir / 'sprites').glob('*.png'))) >= 5
checks['expanded 900x900 map ground'] = 'PlaneGeometry(900,900)' in source
checks['five-phase safe zone'] = all(token in source for token in ['radius:.70','radius:.50','radius:.32','radius:.16','radius:.05'])
checks['zone easing and final phase'] = 'zShrinkElapsed' in source and 'zFinished' in source
checks['expanded minimap scale'] = 'const s=96/450' in source
checks['playable map boundary'] = 'const MAP_LIMIT=438' in source and 'clampWorld(P.x,P.z' in source
checks['named map landmarks'] = all(name in source for name in ['MILITARY BASE','OLD TOWN','INDUSTRIAL YARD','FOREST CAMP','CENTRAL OUTPOST'])
checks['nearest landmark HUD'] = 'nearPoi.name' in source
checks['Three.js dependency present'] = (asset_dir / 'libs/three.min.js').is_file()
kt = (ROOT / 'app/src/main/java/com/example/battlezone/MainActivity.kt').read_text(encoding='utf-8')
checks['LAN room discovery bridge'] = 'fun discoverRooms()' in kt and 'BZ_DISCOVER_V1' in kt
checks['Password-protected multi-client host'] = 'roomPasswordHash' in kt and 'clients.size + 1 >= maxPlayers' in kt
checks['Bluetooth removed'] = 'BLUETOOTH' not in (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
checks['Remote avatar position relay'] = 'bzRemoteAvatar' in source and 'sendPlayerState' in source
checks['LAN protocol documentation'] = (ROOT / 'NETWORK_PROTOCOL.md').is_file()
for label, passed in checks.items():
    print(('PASS' if passed else 'MISSING/NEEDS ACTION') + '  ' + label)

node = shutil.which('node')
if not node:
    print('SKIP  JavaScript syntax (Node.js not installed)')
else:
    scripts = re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>', source, re.S | re.I)
    for index, script in enumerate(scripts):
        if not script.strip():
            continue
        temp = ROOT / f'.validate-script-{index}.js'
        try:
            temp.write_text(script, encoding='utf-8')
            result = subprocess.run([node, '--check', str(temp)], capture_output=True, text=True)
            if result.returncode:
                print(f'FAIL  JavaScript block {index}:\n{result.stderr}')
                raise SystemExit(1)
        finally:
            temp.unlink(missing_ok=True)
    print(f'PASS  JavaScript syntax ({sum(bool(x.strip()) for x in scripts)} script blocks)')

if not checks['Three.js dependency present']:
    print('\nNext step: run `python download_threejs.py` on a computer with internet access.')
print('\nStatic checks complete. Android build and device behavior are not verified here.')
if not all(checks.values()):
    sys.exit(1)
