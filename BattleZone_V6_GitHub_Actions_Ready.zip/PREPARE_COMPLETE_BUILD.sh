#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 setup_assets.py
if [ -x ./gradlew ]; then
  ./gradlew :app:assembleDebug
else
  echo "Gradle wrapper script is not included. Open this project in Android Studio and run app:assembleDebug." >&2
  exit 2
fi
