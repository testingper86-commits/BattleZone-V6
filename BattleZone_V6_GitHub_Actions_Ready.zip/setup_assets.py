#!/usr/bin/env python3
"""One-click download of every third-party runtime file Battle Zone needs (all open source, pinned to Three.js r128).
Run from the project root with internet access:  python setup_assets.py
Android Studio's build does the same automatically (Gradle tasks downloadThreeJs / downloadOptionalLibs)."""
import re, sys
from pathlib import Path
from urllib.request import Request, urlopen

WWW = Path(__file__).resolve().parent / "app/src/main/assets/www"
JS = "examples/js/"
FILES = [  # (target relative to www, path inside three@0.128.0 package or full url list, required, min size)
    ("libs/three.min.js", "build/three.min.js", True, 300_000),
    ("libs/GLTFLoader.js", JS + "loaders/GLTFLoader.js", False, 5_000),
    ("libs/FBXLoader.js", JS + "loaders/FBXLoader.js", True, 5_000),
    ("libs/fflate.min.js", JS + "libs/fflate.min.js", True, 5_000),
    ("libs/SkeletonUtils.js", JS + "utils/SkeletonUtils.js", True, 1_000),
    ("libs/NURBSCurve.js", JS + "curves/NURBSCurve.js", False, 1_000),
    ("libs/NURBSUtils.js", JS + "curves/NURBSUtils.js", False, 1_000),
]
MIRRORS = ["https://cdn.jsdelivr.net/npm/three@0.128.0/", "https://unpkg.com/three@0.128.0/"]
THREE_CDNJS = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"

def is_r128(data: bytes) -> bool:
    m = re.search(rb"REVISION\s*=\s*[\"'](\d+)[\"']", data)
    return (m.group(1) == b"128") if m else bool(re.search(rb"[\"']128[\"']", data))

bad = 0
for rel, pkg, required, minsize in FILES:
    dest = WWW / rel
    if dest.is_file() and dest.stat().st_size >= minsize and (rel != "libs/three.min.js" or is_r128(dest.read_bytes())):
        print(f"OK      {rel} (already present)"); continue
    urls = [m + pkg for m in MIRRORS]
    if rel == "libs/three.min.js": urls.insert(0, THREE_CDNJS)
    done = False
    for u in urls:
        try:
            data = urlopen(Request(u, headers={"User-Agent": "BattleZone-setup"}), timeout=40).read()
        except Exception as e:
            print(f"  {u} -> {e}"); continue
        if len(data) < minsize or (rel == "libs/three.min.js" and not is_r128(data)):
            print(f"  {u} -> unexpected content"); continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists(): dest.rename(dest.with_name(dest.name + ".replaced-backup"))
        dest.write_bytes(data); print(f"FETCHED {rel} ({len(data):,} bytes)"); done = True; break
    if not done:
        print(("FAILED  " if required else "skipped ") + rel); bad += required
print("\nAll required files ready." if not bad else f"\n{bad} required file(s) missing - check your internet connection and run again.")
sys.exit(1 if bad else 0)
