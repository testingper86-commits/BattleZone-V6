# Battle Zone LAN discovery fix

## What was wrong

The earlier scanner sent UDP probes to a few hard-coded broadcast addresses and listened on a random UDP source port. That can fail on routers/hotspots that block limited broadcast or use a different subnet. The host's periodic room announcements were sent to UDP 42425, which a scanner bound to a random port would not receive.

## Changes

- Scanner now binds UDP 42425 and can receive both direct responses and periodic announcements.
- Scanner discovers IPv4 broadcast destinations from active network interfaces, with fallback addresses.
- Scanner sends several probe rounds and listens for a longer window to tolerate dropped broadcast packets.
- Host sends announcements to discovered interface broadcast destinations.
- Added `BattleZoneNet` log messages for host bind, probe targets, received requests, found rooms, and failures.
- TCP host uses explicit reusable bind on `0.0.0.0:42424`.
- Single-player code and Bluetooth behavior are unchanged; multiplayer remains Wi-Fi/hotspot only.

## Test procedure

1. Install the same APK on both phones and connect them to the same Wi-Fi router (disable guest Wi-Fi/client isolation if enabled).
2. On phone A create a password-protected room; verify status says `hosting` and includes a local IP.
3. On phone B tap Find nearby rooms.
4. If no room appears, collect logs from both devices:

```cmd
adb logcat -c
adb logcat -v time BattleZoneNet:I BattleZoneWeb:D AndroidRuntime:E System.err:W *:S
```

5. Check router settings for AP/client isolation. Both phones must be on the same LAN/subnet. Some guest networks block peer-to-peer traffic regardless of game code.

## Limits

This is a targeted discovery/network diagnostic fix, not proof of working multiplayer on every router. The project still requires a device-to-device test. Full authoritative combat and match-state synchronization are separate tasks.
