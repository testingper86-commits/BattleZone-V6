#!/usr/bin/env python3
"""Prepare Battle Zone's pinned runtime and standard Gradle wrapper when online.

This script never creates placeholder JavaScript/JAR files. It only saves Three.js
when its contents identify the official classic r128 build, and asks Gradle itself
to generate wrapper files. Run from this project root with Python 3 and internet access.
"""
from pathlib import Path
from urllib.request import Request, urlopen
import argparse, re, subprocess, sys

ROOT = Path(__file__).resolve().parent
WWW = ROOT / "app/src/main/assets/www"
THREE = WWW / "libs/three.min.js"
THREE_URLS = [
    "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
    "https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js",
    "https://unpkg.com/three@0.128.0/build/three.min.js",
]

def valid_three(data: bytes) -> bool:
    if len(data) < 300_000 or b"REVISION" not in data:
        return False
    m = re.search(rb"REVISION\s*=\s*[\"'](\d+)[\"']", data)
    return bool(m and m.group(1) == b"128")

def prepare_three() -> bool:
    if THREE.is_file() and valid_three(THREE.read_bytes()):
        print(f"PASS Three.js r128 already present ({THREE.stat().st_size:,} bytes)")
        return True
    errors = []
    for url in THREE_URLS:
        try:
            req = Request(url, headers={"User-Agent": "BattleZone-build-preflight/1.0"})
            with urlopen(req, timeout=25) as response:
                data = response.read()
            if not valid_three(data):
                errors.append(f"{url}: response failed Three.js r128 validation")
                continue
            THREE.parent.mkdir(parents=True, exist_ok=True)
            tmp = THREE.with_suffix(".js.tmp")
            tmp.write_bytes(data)
            tmp.replace(THREE)
            print(f"PASS Downloaded and validated official Three.js r128 ({len(data):,} bytes)")
            return True
        except Exception as exc:
            errors.append(f"{url}: {type(exc).__name__}: {exc}")
    print("BLOCKED Three.js r128 could not be fetched; no placeholder was created.")
    for err in errors:
        print("  " + err)
    return False

def prepare_wrapper() -> bool:
    jar = ROOT / "gradle/wrapper/gradle-wrapper.jar"
    if jar.is_file() and jar.stat().st_size > 10_000:
        print(f"PASS Gradle wrapper JAR already present ({jar.stat().st_size:,} bytes)")
        return True
    if sys.platform.startswith("win"):
        command = [str(ROOT / "gradlew.bat"), "wrapper", "--gradle-version", "8.9", "--distribution-type", "bin"]
    else:
        command = [str(ROOT / "gradlew"), "wrapper", "--gradle-version", "8.9", "--distribution-type", "bin"]
    try:
        result = subprocess.run(command, cwd=ROOT, check=False)
        if result.returncode == 0 and jar.is_file() and jar.stat().st_size > 10_000:
            print(f"PASS Gradle generated official wrapper JAR ({jar.stat().st_size:,} bytes)")
            return True
        print(f"BLOCKED Gradle wrapper generation did not complete (exit {result.returncode}).")
    except Exception as exc:
        print(f"BLOCKED Could not launch Gradle wrapper generation: {type(exc).__name__}: {exc}")
    print("  Check Java, network access, and plugin repository access; then rerun this script.")
    return False

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-three", action="store_true", help="do not fetch Three.js")
    parser.add_argument("--skip-wrapper", action="store_true", help="do not generate the official Gradle wrapper")
    args = parser.parse_args()
    results = []
    if not args.skip_three:
        results.append(prepare_three())
    if not args.skip_wrapper:
        results.append(prepare_wrapper())
    if results and all(results):
        print("\nPASS Required runtime and wrapper preparation completed. Run ./gradlew assembleDebug next.")
        return 0
    print("\nINCOMPLETE: resolve the BLOCKED items above, then rerun this script. No fake dependencies were written.")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
