# Battle Zone — Graphics, UI and Gameplay Fix Pass

This pass targets the reported single-player issues while preserving the offline game and the existing LAN multiplayer bridge.

## Changes in source
- Prevent loot pickup while the player is parachuting/falling or driving, so weapons cannot be collected before landing.
- Add dedicated gas, brake, steering and exit controls that only appear while driving.
- Add driver cockpit camera by default, with a CAM button to switch to an external vehicle camera.
- Add a simple dashboard, steering wheel, seat and translucent cabin glass to vehicle models.
- Add line-of-sight checks for bot attacks against solid wall/building geometry so bots do not damage players through walls.
- Keep player weapon raycasts checking the nearest target/solid hit, preserving wall cover.
- Apply a restrained cinematic color-grade treatment and a glass-style touch-control redesign.
- Increase the distance at which detailed procedural character rigs are used, subject to device performance.

## Known limitations
- This is a procedural Three.js prototype, not a finished AAA asset pipeline. Character meshes/animations, vehicle interiors and building architecture remain simplified.
- Collision is still approximate (axis-aligned obstacle bounds). Door openings and complex geometry need playtesting and possibly a dedicated physics engine.
- Bot line-of-sight uses raycasts against the current `solid` mesh list. Every future solid building/prop must be registered there to block shots.
- No physical-device playtest or Android build was run in this environment. Test controls, cockpit orientation, collisions, bot cover and performance on the target phones.
- `three.min.js` remains a required local dependency at `app/src/main/assets/www/libs/three.min.js`; this package may contain only the dependency instructions if the library is not bundled.
