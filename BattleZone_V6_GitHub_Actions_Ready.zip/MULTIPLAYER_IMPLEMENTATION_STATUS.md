# Local multiplayer status

## Implemented in source
- Android WebView JavaScript bridge for local LAN rooms.
- Wi-Fi/hotspot TCP host with multiple client sockets, room capacity limits (2–8), room code, player names and password validation.
- UDP LAN room discovery with room name, code, mode, occupancy and maximum players.
- Host relays JSON messages among clients; joins/leaves and disconnects are surfaced to the game UI.
- Periodic player position/yaw/health/alive state messages and simple remote-player avatar previews in the 3D scene.
- Offline play remains the default; no external game server or Bluetooth is used.

## Still not a complete competitive multiplayer game
- Combat is not authoritative: the host does not validate aim/hits/damage/eliminations.
- Player state is client-supplied and can be forged; remote avatars are a preview integration.
- Full synchronized TDM scoring, FFA/Battle Royale match outcomes, loot/inventory, vehicles, bots, safe zone and reconnect/resume are not complete.
- UDP broadcast room discovery depends on Wi-Fi/hotspot support; Android vendor behavior and client isolation vary.
- Must test 2, 4 and 8 physical Android devices, wrong password, full room, host exit, network loss, latency and thermal/frame performance.

## Security
- Password hash is checked by the host, but the current TCP transport is not encrypted. It is intended for a trusted local test network only.
