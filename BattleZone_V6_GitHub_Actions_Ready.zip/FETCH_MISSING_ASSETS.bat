@echo off
setlocal
cd /d "%~dp0"
if not exist gradlew.bat (
  echo ERROR: Run this file from the BattleZoneLocalMultiplayer project root; gradlew.bat is missing.
  pause
  exit /b 1
)
echo Fetching required Three.js r128 and optional character loaders/models.
echo An internet connection is required on this PC.
call gradlew.bat downloadThreeJs downloadOptionalLibs downloadSoldierModels
if errorlevel 1 (
  echo Asset download/build task failed. Check the network connection and messages above.
  pause
  exit /b 1
)
echo Finished. Verify app/src/main/assets/www/libs and rebuild the APK.
pause
