# Battle Zone LAN protocol (version 1)

## Transport
- TCP gameplay/lobby channel: port `42424`, newline-delimited UTF-8 JSON, one object per line.
- UDP room discovery: port `42425`, LAN broadcast request `BZ_DISCOVER_V1`; response prefix `BZ_ROOM_V1|` followed by JSON room metadata.
- All phones must be on the same Wi-Fi LAN or hotspot. Guest/client isolation and hotspot firewall rules can block local traffic.
- No internet matchmaking server and no Bluetooth transport are used.

## Room join
Client first line:
`{"kind":"hello","protocol":1,"roomId":"ROOMCODE","password":"...","name":"Player"}`

Host checks protocol, room ID, SHA-256 password hash, and room capacity, then replies with an `ok` welcome or an error. Passwords should be at least four characters in the UI; use a stronger, unique password for private tests. This prototype does not provide TLS, so do not treat it as secure against a malicious device on the same LAN.

## Relayed message kinds
- `player-state`: position, yaw/pitch, health/alive flag and cosmetic weapon value; relayed to other clients for remote-avatar previews.
- `combat`: reserved extension point; it is not yet an authoritative damage protocol.
- `peer-joined`, `peer-left`: host-generated lobby notifications.

## Combat protocol v1 (implemented in www/js/netplay.js, envelope `{kind:"combat",event:{t:...},senderId}`)
Host-authoritative. `senderId` is stamped by the Android relay (clients cannot forge it); clients accept
everything except `hit` only when `senderId === "HOST"`.
- client -> host `hit` `{target,w,head,mul}`: a *claim*. Host checks: both alive, not same player, no friendly fire (TDM),
  spawn protection (2.5 s), fire-rate limit (70 % of weapon cooldown), range (weapon range + 8 m using last known positions),
  damage multiplier capped at 1.5. Damage is computed by the host from its own weapon table.
- host -> all: `hp {id,hp,by,dmg,head,respawn}`, `kill {victim,killer,w,head}`, `roster {mode,players{id:{n,team,k,d}},score}`,
  `start`, `end {winner,roster}`.
- Elimination = instant respawn at a team spawn with 2.5 s protection. Match ends at 25 team kills (TDM) / 20 kills (FFA).
- LAN matches: the host simulates bots to fill empty slots (maxPlayers - players). Bots are hostile to everyone, respawn after 4 s,
  and one bot is retired whenever a real player joins. Host broadcasts `bots` snapshots at 10 Hz (`[id,x,z,yaw,alive,hp]`); clients render them
  as avatars and send ordinary `hit` claims with target `B<n>`. Bot damage to players goes through the same host-authoritative path. BR mode is forced to TDM/FFA.

## Known limits
Player position is still client-reported (LAN trust model); no TLS; no reconnect/host migration; loot, vehicles and the
safe zone are not synchronised (not used in LAN TDM/FFA). Test on real devices (2/4/8 players) before claiming release quality.
