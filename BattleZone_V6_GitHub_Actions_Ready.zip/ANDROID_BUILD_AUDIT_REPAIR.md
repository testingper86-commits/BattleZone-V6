# Battle Zone V6 — Android Build Audit and Repair

## Project configuration checked

- Android Gradle Plugin: 8.7.3
- Gradle distribution target: 8.9 (`gradle/wrapper/gradle-wrapper.properties`)
- Kotlin Android plugin: 2.0.21
- Android compile/target SDK: 35; minimum SDK: 23
- Java/Kotlin bytecode target: 17
- AndroidX WebKit: 1.12.1; AndroidX Core KTX: 1.15.0
- Application module and `MainActivity.kt` are present. The Android manifest declares a launcher activity and the permissions used by the current network bridge.

## Repairs and safeguards in this package

- Kept the existing game source, professional lobby/settings UI, game assets, and current Gradle versions intact.
- Kept the Gradle build task that downloads and validates Three.js r128 before `preBuild`; it fails clearly if the required 3D engine cannot be obtained.
- Added `prepare_android_build.py`. On an internet-connected computer it fetches Three.js only if the response validates as the official classic r128 build, and asks Gradle to generate the standard wrapper JAR instead of fabricating one. Run `python prepare_android_build.py` from this folder.
- Retained `gradlew` / `gradlew.bat` as convenience launchers. Until the official `gradle-wrapper.jar` is generated, these are not a substitute for the standard Gradle wrapper files expected by normal Android Studio wrapper workflows.

## Checks completed in this packaging environment

- ZIP archive integrity: passed.
- Python syntax for `prepare_android_build.py` and `validate_project.py`: passed.
- JavaScript syntax for inline scripts in `app/src/main/assets/www/index.html`: checked with Node.js.
- Android manifest XML parse: passed.
- Local game asset reference and source-level checks: reported separately in `BUILD_VERIFICATION_REPORT.txt`.
- Reviewed Gradle configuration values and the pre-build dependency task wiring.

## Remaining blockers / unverified tests

1. `app/src/main/assets/www/libs/three.min.js` is absent from this archive. Outbound DNS/network access was unavailable in the packaging environment, so the official library could not be fetched. The game cannot render its Three.js world until it is installed. Do not use a placeholder file.
2. `gradle/wrapper/gradle-wrapper.jar` is absent. The new `prepare_android_build.py` can ask a real Gradle 8.9 installation to generate the standard wrapper on an internet-connected host. If Gradle cannot bootstrap or resolve the Android plugins, generation will remain incomplete.
3. No Android SDK or Gradle distribution is installed in this environment. Gradle sync, Kotlin compilation, resource processing, APK assembly, emulator launch, and physical-device tests could not be run.
4. No runtime claim is made for offline launch, WebGL/GPU behavior, touch interactions, orientation/cutout behavior, pause/resume, or LAN multiplayer. Those need APK/device tests.

## Recommended online-host steps

1. Install Android Studio, JDK 17, and Android SDK platform/build tools 35.
2. Open the `BattleZoneLocalMultiplayer` folder.
3. Run `python prepare_android_build.py` in that folder and resolve any reported blocked dependency.
4. Confirm `app/src/main/assets/www/libs/three.min.js` exists and is the classic r128 build, and confirm `gradle/wrapper/gradle-wrapper.jar` exists.
5. Run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
6. Install `app/build/outputs/apk/debug/app-debug.apk` on a physical Android device and test both online-first dependency setup and offline gameplay after installation.
