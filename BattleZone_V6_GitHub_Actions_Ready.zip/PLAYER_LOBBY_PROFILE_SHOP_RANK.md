# Player lobby, profile, shop and progression patch

- Profile name editing and local image upload (resized to a small JPEG for local storage).
- Separate Maps, Settings, Inventory, Shop, and Rank/Season lobby windows.
- Inventory shows only owned characters, outfits, and gun skins.
- Coin shop for cosmetic outfits, characters and gun-skin choices; legendary operators unlock at level 35/50.
- Local XP/level, Bronze/Silver/Gold/Platinum/Diamond rank points, and seasonal rank reset.
- Graphics, controls, sensitivity, weather, season, match mode, bot difficulty, sound and backup settings shortcuts.

Progress is local-device prototype data, not cloud/account synced. Cosmetic gun skins are inventory/equip metadata and are not yet rendered as detailed 3D weapon textures. Character selection is saved, but distinct fully rigged character models require proper model assets. Gameplay/device testing is still required.
