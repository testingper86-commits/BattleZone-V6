# Open-source military character asset upgrade

## Intended source
This project includes an installer for the public `cktang88/3d-fps` repository:
https://github.com/cktang88/3d-fps

The source project's `ASSETS.md` identifies a rigged soldier model and a tactical-suit model. The referenced third-party character models are CC BY 4.0; attribution and license preservation are required. Read `app/src/main/assets/www/models/characters/THIRD_PARTY_LICENSE_NOTICE.txt` after running the installer and re-check upstream licenses before shipping.

## Install model assets
1. On Windows, extract this project.
2. Ensure Python 3 and internet access are available.
3. Double-click `INSTALL_OPEN_SOURCE_MILITARY_MODELS.bat`.
4. The models are downloaded into `app/src/main/assets/www/models/characters/`.

## Important technical status
This installer adds the source model files to the local asset folder. It does **not** by itself complete the game's runtime replacement. Battle Zone currently builds its character rigs procedurally in `index.html`, and needs a compatible Three.js r128 `GLTFLoader`, skeleton cloning/animation setup, scale/orientation calibration, and an explicit adapter between the imported model and existing gameplay actor objects. Until that adapter is implemented and tested, the game will continue using its current procedural characters.

These source models are a useful open-source military-style starting point, but should not be represented as photorealistic AAA characters. The sourced rigged model may need additional face/hair detail, tactical gear, and LOD optimization.
