@echo off
cd /d "%~dp0"
python setup_assets.py
pause
