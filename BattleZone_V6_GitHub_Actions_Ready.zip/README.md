# Battle Zone Offline — Android Studio project

This project wraps the supplied `Battle Zone Offline` HTML game in an Android WebView and serves it from app assets. It is configured for landscape, fullscreen/immersive play, JavaScript, localStorage/DOM storage, and WebGL.


## Realistic graphics + tactical AI update

This revision preserves the original game controls, lobby, maps, weapons, vehicles, weather, localStorage progression, and offline WebView wrapper. Changes include:

- Balanced filmic tone mapping and sRGB output for richer lighting/color.
- Layered low-poly tree crowns with shadow casting only when high graphics is selected.
- Enemy roles: cover-seeking, flanking, and aggressive rush behavior, using existing scene obstacles.
- Slightly capped high-quality pixel ratio for more stable mobile performance.

The project is still a Three.js/WebView game; visual quality and frame rate depend on the phone GPU/WebView. The Three.js r128 library must exist at `app/src/main/assets/www/libs/three.min.js` (run `python download_threejs.py` or use the PowerShell command below if it is missing).

## Important one-time dependency step

The supplied HTML used Three.js r128 from cdnjs. The HTML has been changed to load it locally from:

`app/src/main/assets/www/libs/three.min.js`

**That Three.js file is not bundled in this ZIP** because this build environment could not reach the CDN. You must download the matching r128 file once before building. Without it, the game will not run.

### Windows PowerShell

From the extracted project folder, run:

```powershell
New-Item -ItemType Directory -Force "app/src/main/assets/www/libs" | Out-Null
Invoke-WebRequest "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" -OutFile "app/src/main/assets/www/libs/three.min.js"
```

Or run `python download_threejs.py` from the project folder on a computer with internet access.

Expected file size should be roughly a few hundred KB. Confirm the file exists at the exact path above.

## Build the APK

1. Install Android Studio and an Android SDK platform for API 35.
2. Extract this ZIP.
3. Complete the one-time Three.js download step above.
4. Open the extracted `BattleZoneLocalMultiplayer` folder in Android Studio.
5. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks.
6. Choose **Build > Build APK(s)**.
7. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Offline verification checklist

- Install and launch with airplane mode enabled.
- Test lobby and match start.
- Test movement, look, firing, and touch controls.
- Test sound after tapping the game UI.
- Test localStorage persistence after closing/reopening.
- Test on the target phone for WebGL crashes, heat, frame rate, and memory use.

## Notes / limitations

- This ZIP is an Android Studio project scaffold, **not a prebuilt APK**.
- The app declares Android `INTERNET` permission for local TCP/UDP sockets. It does not require an external game server, account or internet connection for LAN play; the Three.js library must be bundled locally for offline launch.
- Gradle may need internet once to download Android Gradle Plugin and AndroidX WebKit dependencies.
- The game is still rendered by the Android System WebView. WebGL support and performance depend on the phone's WebView/GPU.
- If the game has any other network-loaded resources not present in the supplied HTML, those would also need to be bundled locally.


## Nearby Wi-Fi multiplayer
The local multiplayer panel supports password-protected Wi-Fi/hotspot rooms, automatic LAN room discovery, 2–8 room capacity settings, multi-client TCP relay and basic remote-player position/avatar previews. Bluetooth has been removed. See `MULTIPLAYER_IMPLEMENTATION_STATUS.md` and `NETWORK_PROTOCOL.md` for the exact scope. The current implementation is a multiplayer foundation: authoritative hit validation, health/elimination rules, match scoring and complete gameplay state synchronization are not finished or device-validated.


## Professional match modes
The lobby includes Battle Royale, offline Team Deathmatch (three AI teammates; first to 25 player kills) and offline Free-for-All (first to 20 player kills). Arena modes use ground spawn and respawns. These are offline AI modes; they do not imply synchronized LAN multiplayer. See `PROFESSIONAL_UPGRADE_STATUS.md` for the exact implemented scope and release checklist.

## Bundled graphics assets
This project now includes local procedural textures and sprites in `app/src/main/assets/www/textures/` and `app/src/main/assets/www/sprites/`. The ground plane uses the grass maps, tree trunks use bark maps, and rock props use a rock texture. See `GRAPHICS_ASSETS_INTEGRATION.md` for the exact list and limitations. The sprite images are bundled but are not yet connected to every gameplay effect. These changes have not been Android-build/device tested.


## Map expansion and five-phase safe zone (latest update)

- The main ground plane is now 900 × 900 world units, with wider prop/loot/bot placement and longer view/fog distances.
- Battle Royale starts with a 320-unit safe-zone radius and uses five target radius ratios: 70%, 50%, 32%, 16%, and 5%.
- The zone moves and shrinks with smooth easing; the HUD shows phase/countdown/closing status; damage outside the zone increases by phase.
- See `MAP_EXPANSION_AND_FIVE_PHASE_ZONE.md` for details and test limitations.
- The five-phase behavior is source-level implemented but not yet Android/device play-tested. The local Three.js r128 dependency is still missing from this package and must be downloaded before running the game offline.


## Open-source voice pack
Run `INSTALL_OPEN_SOURCE_VOICE_PACK.bat` on a computer with internet and Python 3, then rebuild the Android app. See `OPEN_SOURCE_VOICE_PACK.md`.


## Open-source military character assets
See `MILITARY_CHARACTER_ASSETS.md` and run `INSTALL_OPEN_SOURCE_MILITARY_MODELS.bat` to fetch the third-party models and license notices. Runtime replacement is not yet complete.

## V6 dependency preparation and completion audit
See `V6_COMPLETION_AUDIT.md`. On a computer with internet access, run `PREPARE_COMPLETE_BUILD.bat` (Windows) or `python3 setup_assets.py` to fetch the official, pinned Three.js r128 runtime and matching optional loaders before building. The ZIP itself does not contain the Three.js binary because outbound network access was unavailable when it was prepared; this is explicitly documented and no fake placeholder library was added.
