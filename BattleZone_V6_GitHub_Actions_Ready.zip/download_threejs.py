#!/usr/bin/env python3
"""Kept for compatibility: downloads everything via setup_assets.py."""
import runpy, sys
from pathlib import Path
runpy.run_path(str(Path(__file__).resolve().parent / "setup_assets.py"), run_name="__main__")
