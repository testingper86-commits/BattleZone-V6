BATTLE ZONE V6 — ANDROID STUDIO SOURCE PACKAGE

Open the folder BattleZoneLocalMultiplayer in Android Studio (not the ZIP itself). Use JDK 17 and Android SDK 35. Allow Gradle Sync and the first build to access the internet so the project can download the required Three.js r128 classic file and compatible optional loaders.

Then use Build > Build Bundle(s) / APK(s) > Build APK(s). This package is source code, not a prebuilt or device-verified APK.

Offline check: after a successful first build and installation, disable Wi-Fi/mobile data and verify single-player. The runtime Three.js file must exist at app/src/main/assets/www/libs/three.min.js in the built project.

Environment textures from the compact pack are copied under app/src/main/assets/www/assets/environment/textures/. They are bundled locally but are not guaranteed to be used by the current map code until materials are wired to them.

Known limitations: multiplayer needs physical-device validation; complete safe-zone/vehicle/loot synchronization is not certified; dedicated shooting, death, and reload animations are not included as compatible clips; no APK build or Android device runtime test was performed during packaging.
