# Battle Zone - honest feature status (v4)
Legend: OK = code present and exercised by automated tests/stand-in browser run; UNVERIFIED = code present, needs a real device/asset;
MISSING = not in the project.  "OK" never means "looks good on a phone" - nothing here has been run on real hardware by the author of this file.

| Area | Status |
|---|---|
| Three.js r128 delivery, black-screen diagnostics, WebView logging | OK (auto-download in Gradle; needs internet once) |
| 10 maps, 5-phase zone, 23 weapons, bot line-of-sight, airplane drop, vehicles, ranks to Conqueror, 17 characters, voice packs | Present; start of a match runs without JS errors. Visual quality UNVERIFIED |
| LAN: host/join, UDP discovery, password, 2-8 players | Code present; real Wi-Fi/hotspot behaviour UNVERIFIED |
| LAN: host-authoritative hits, health, kills, TDM/FFA score, match end, anti-forgery | OK (simulated 2-device test) |
| LAN: bots fill empty slots (host-simulated, hostile to all, respawn, retire when a player joins), bots fight remote players | OK (simulated test) |
| Kenney FBX characters (real files now in project): local player body, offline bots/allies, remote LAN players, LAN-bot avatars; skins per character; idle/run/jump | Files verified by parsing (bones match, 2 clips per file, faces +Z); loader/dress flow tested with fake loaders. Real FBXLoader rendering UNVERIFIED on device |
| Walk / shoot / die animations | MISSING in this Kenney pack (walk = slowed run). Add clips via manifest.json |
| Held weapon on the FBX body | Simple gun box at the hip for bots, remote players and your third-person body (not hand-attached, does not change with weapon) |
| Lobby 3D preview of the model | MISSING (lobby uses portraits) |
| Zone / vehicles / loot / weather synchronised in LAN | MISSING (LAN modes are TDM/FFA; these stay local) |
| Voice files licensing | UNVERIFIED - check the origin of audio/voicepacks/*.mp3 |
| Performance on low-end phones, APK install/test | UNVERIFIED |

## Required third-party files (all open source) and how they arrive
| File | Source | How |
|---|---|---|
| libs/three.min.js (r128, MIT) | cdnjs / jsDelivr / unpkg | Gradle `downloadThreeJs` on every build, or `SETUP_ASSETS.bat` / `python setup_assets.py` |
| libs/FBXLoader.js, fflate.min.js, SkeletonUtils.js, GLTFLoader.js, NURBS*.js (r128 classic, MIT) | jsDelivr / unpkg three@0.128.0 | Gradle `downloadOptionalLibs`, or the same setup script |
| models/characters/kenney (CC0) | Kenney - already bundled | included |
| audio/voicepacks | bundled | licence of the clips NOT verified |
Needs internet once. If the PC is offline the build stops with instructions; nothing is silently skipped.
