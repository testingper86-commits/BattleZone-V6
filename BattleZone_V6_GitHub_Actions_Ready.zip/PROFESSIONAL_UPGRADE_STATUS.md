# Battle Zone — Professional Upgrade Status

## Included in this source package

- Existing offline Three.js game, maps, weapons, vehicles, touch controls, HUD, weather/season system, inventory, skins, missions and saved progression.
- Local generated texture maps for grass, forest floor, dry dirt, sand, concrete, weathered rock, bark, military metal and asphalt (base-color, roughness and height maps).
- Five bundled effect/vegetation sprites: muzzle flash, impact spark, smoke puff, dust puff and vegetation blades.
- Texture integration helpers and material usage for the ground, tree trunks and rock props.
- Three offline match modes in the main lobby:
  - **Battle Royale**: retains the original drop/zone/elimination loop.
  - **Team Deathmatch**: ground spawn, three bot teammates, respawns and a 25 player-kill target.
  - **Free-for-All**: ground spawn, no teammates, respawns and a 20 player-kill target; bots can engage other bots.
- Bot difficulty selection (Easy / Normal / Hard), existing cover/flank/rush behavior, mobile control customization, sound toggle, weather/season controls, Low/High rendering and battery-saver option.
- Android WebView wrapper and LAN room source: password-protected rooms, UDP discovery, multi-client TCP relay and remote-player position/avatar previews.
- Project notes, network protocol notes, build instructions and original HTML backup.

## Not included / not yet production-ready

- Three.js r128's `three.min.js` is not bundled because the build environment could not resolve the CDN. Run `python download_threejs.py` from the project root on a computer with internet, then confirm `app/src/main/assets/www/libs/three.min.js` exists.
- The five sprites and most additional material maps are bundled assets; not every sprite/material is wired into gameplay. There are no new full rigged soldier/weapon models or authored animation clips in this pack.
- TDM/FFA are local offline modes against AI. They are not yet synchronized across phones.
- LAN relay and remote-avatar preview are present in source, but authoritative synchronized combat, damage, eliminations, team scoring, shared bots and reconnect are unfinished. **Eight-player gameplay is not implemented or verified.**
- No APK was built, installed, or device-tested in this environment. No FPS, thermal, battery, or memory claim is verified.

## Suggested release gate

1. Download the exact Three.js r128 dependency.
2. Open this project in Android Studio and build a debug APK.
3. Test each match mode, touch controls, audio, save/load, each map and graphics profile.
4. Test on a low-end and a higher-end Android phone, with airplane mode enabled.
5. Fix all runtime errors and performance bottlenecks before release.
6. Treat multiplayer as a separate milestone: implement host-authoritative state and test 2, 4 and 8 physical devices before advertising support.


## Latest map-related update

- Expanded map ground, camera/fog range, prop/loot placement, bot spawn candidates, initial zone radius, and minimap scale.
- Replaced the repeated single-step zone shrink with five configured phases and eased transitions.
- Added phase/countdown HUD status and escalating outside-zone damage.
- See `MAP_EXPANSION_AND_FIVE_PHASE_ZONE.md`.
- Static source validation only; no Android APK build or real-device play test is claimed.
