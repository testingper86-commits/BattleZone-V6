# Graphics asset integration status

## Bundled assets
The Android WebView now serves real local files from `app/src/main/assets/www/textures/` and `app/src/main/assets/www/sprites/`.

- 9 procedural material sets, each with base-color, roughness, and height maps.
- 5 transparent particle/vegetation sprites.
- The ground plane uses the grass base-color and roughness maps.
- Generated tree trunks use bark maps.
- Rock props use the weathered-rock texture.

The game HTML uses relative local paths (`./textures/...` and `./sprites/...`), so these assets do not require an internet connection once packaged. Texture loading is asynchronous; a missing texture is logged in the in-game error display.

## Honest limitations
- These are procedural starter textures, not scanned AAA PBR assets.
- The sprites are bundled but are not yet wired into every existing weapon/effect animation.
- Height maps are included but are not automatically applied as geometric displacement.
- No new rigged soldier/weapon models or animation clips are included.
- Integration has not been tested on an Android device and no APK build has been verified.

## Verify
1. Open the project in Android Studio and ensure `app/src/main/assets/www/libs/three.min.js` exists.
2. Build and run.
3. Confirm the ground has a tiled grass texture and tree trunks have bark texture.
4. Test low graphics and monitor frame rate; reduce texture repeats/detail if required.


## Asset integration update
- Added custom Battle Zone launcher icon at all standard Android mipmap densities (48, 72, 96, 144, 192 px) and wired it into AndroidManifest.xml.
- Added an animated randomized boot overlay at startup using the existing local loading scenes.
- Added event-triggered character voice playback for spawn, combat elimination, and victory (using the existing local MP3 clips).
- Added additional low-poly tactical equipment detail to the articulated Three.js operator rig. This is a procedural mesh enhancement, not a professionally authored scanned/AAA rigged character asset.
- No external downloads or network assets are required for these additions.
