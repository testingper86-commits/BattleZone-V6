# GitHub Actions build — Battle Zone V6

This project is prepared to build on a GitHub-hosted Ubuntu runner. The workflow is:

`.github/workflows/android-build.yml`

## What the workflow does

1. Checks out the repository.
2. Installs JDK 17 and Android SDK platform/build tools for API 35.
3. Installs Gradle 8.9 and generates the official Gradle Wrapper because `gradle-wrapper.jar` was not included in the source archive.
4. Runs `:app:assembleDebug`. The app Gradle script fetches the required classic Three.js r128 file and optional loader files; the build fails if the required Three.js dependency cannot be obtained.
5. Publishes `BattleZone-debug-apk` as a downloadable workflow artifact when the build succeeds.

## How to use it

1. Extract the ZIP and upload/push the **contents of the `BattleZoneLocalMultiplayer` project folder** to the root of your GitHub repository. The `.github` directory must be included.
2. In GitHub, open **Actions** and enable workflows if prompted.
3. Push to `main` or `master`, open a pull request to either branch, or run **Android Build** manually using **Run workflow**.
4. Open the workflow run. If it succeeds, download `BattleZone-debug-apk` from **Artifacts**.
5. If it fails, open the failed step and inspect its logs. The workflow also uploads build diagnostics when available.

## Honest verification status

- The workflow YAML and project paths were checked locally.
- The ZIP archive is checked for integrity after packaging.
- A GitHub Actions run has **not** been executed from this environment, so no APK build success is claimed.
- The workflow requires GitHub-hosted runner network access to Maven/Google repositories and the configured Three.js CDN mirrors.
- No emulator or physical-device gameplay test is performed by this workflow.

## Build configuration observed

- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Compile SDK / target SDK: 35
- Minimum SDK: 23
- Java/Kotlin target: 17
