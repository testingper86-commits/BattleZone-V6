# Build and Test Status

## Verified in this workspace
- Android WebView wrapper, Gradle Kotlin DSL files, game assets and source documentation are present.
- Static validator passes the map/mode/texture checks, LAN discovery/password/multi-client source checks, and all inline JavaScript syntax checks.
- LAN bridge source includes room creation, UDP discovery, password validation, multiple TCP clients, JSON relay, disconnect cleanup and remote-player position/avatar preview messages.
- Bluetooth permissions and transport UI have been removed.

## Not verified / blockers
- No Gradle build was run because an Android SDK/Gradle build toolchain is not available in this workspace; Kotlin compilation is not verified.
- No APK was produced and no Android device test was run.
- Three.js r128 is still missing at `app/src/main/assets/www/libs/three.min.js`; outbound DNS/network access failed in this environment. The game will not launch correctly until this dependency is added.
- Multiplayer is not production-complete: authoritative hit/damage/elimination/scoring, full match-state sync, bots shared across devices, reconnect and host-migration are unfinished.
- Wi-Fi/hotspot discovery, room password rejection, capacity limits, 2/4/8-player behavior, host shutdown and performance need physical-device testing.

## Build prerequisites
1. On a computer with internet access, download the exact Three.js r128 file from `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js` into `app/src/main/assets/www/libs/three.min.js`.
2. Open the project folder in Android Studio with JDK 17 and an Android SDK installed; sync Gradle.
3. Build a debug APK, then test offline launch and LAN behavior on physical devices.

Static checks are not a substitute for an Android build or runtime test. Do not advertise a verified 8-player competitive multiplayer release until the remaining gameplay sync and device tests are complete.
