\
#!/usr/bin/env python3
"""Download open-source soldier models and their license/source notices.
Run from the project root on a computer with internet access.
"""
from pathlib import Path
from urllib.request import urlopen, Request
from zipfile import ZipFile
from io import BytesIO
import json, shutil, sys

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "app/src/main/assets/www/models/characters"
DEST.mkdir(parents=True, exist_ok=True)

# Public GitHub source project documents these models and their individual licenses.
REPO_ZIP = "https://github.com/cktang88/3d-fps/archive/refs/heads/main.zip"
NOTICE = """OPEN-SOURCE CHARACTER ASSET NOTICE

This installer fetches the source repository at:
https://github.com/cktang88/3d-fps

The repository's ASSETS.md identifies:
- soldier.glb: rigged military soldier / fallback body by BAMEN, CC BY 4.0.
- soldier_tac.glb: military tactical suit by DanlyVostok (1799danly), CC BY 4.0.
- Quaternius Universal Animation Library motions: CC0 (as identified by the source project).

These third-party assets retain their original licenses. CC BY 4.0 assets require appropriate attribution,
a link to the license, and indication of changes. Do not remove the original credits. Review the source
repository's current ASSETS.md and each source page before shipping a public/commercial build.

Sources:
https://github.com/cktang88/3d-fps
https://sketchfab.com/3d-models/military-tactical-suit-lowpolygameready-ef698ce36b1545a78ce592dd3db4c7ed
https://sketchfab.com/3d-models/free-military-soldier-rigged-e9c56308a67d4a3db62e914fafa4d198
https://creativecommons.org/licenses/by/4.0/
"""
try:
    req = Request(REPO_ZIP, headers={"User-Agent": "BattleZone-open-source-asset-installer"})
    with urlopen(req, timeout=60) as response:
        archive = ZipFile(BytesIO(response.read()))
    names = archive.namelist()
    selected = {}
    for name in names:
        low = name.lower()
        if low.endswith((".glb", ".gltf")) and (
            low.endswith("/models/characters/soldier.glb") or
            low.endswith("/models/characters/soldier_tac.glb")
        ):
            selected[Path(name).name] = name
    if "soldier.glb" not in selected:
        # Repo structure may change; fail rather than silently installing unrelated assets.
        raise RuntimeError("Could not find models/characters/soldier.glb in the source archive.")
    for filename, member in selected.items():
        target = DEST / filename
        target.write_bytes(archive.read(member))
        print(f"Installed {filename}: {target.stat().st_size:,} bytes")
    (DEST / "THIRD_PARTY_LICENSE_NOTICE.txt").write_text(NOTICE, encoding="utf-8")
    print("\nDownloaded model files and license notice.")
    print("NOTE: The models are now in the local assets folder; runtime loader integration still requires")
    print("matching GLTFLoader + skeleton/animation adaptation. The game remains on its current procedural")
    print("fallback until that integration is completed and tested.")
except Exception as exc:
    print(f"ERROR: {exc}", file=sys.stderr)
    sys.exit(1)
