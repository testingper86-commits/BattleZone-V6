# Battle Zone V6 — Asset Package Status

This package preserves the existing offline game and bundles all asset files that were already present in the supplied project. It does **not** claim that the game is fully complete or that missing animation files have been fabricated.

## Bundled real assets

- Kenney character FBX: `app/src/main/assets/www/models/characters/kenney/Model/characterMedium.fbx`
- Kenney skins: `.../kenney/Skins/*.png` (4 textures)
- Kenney animation FBX clips: `.../kenney/Animations/idle.fbx`, `run.fbx`, `jump.fbx`
- Existing UI, portrait, loading, environment textures, sprites, and voice-pack audio under `app/src/main/assets/www/`
- Existing Three.js integration code, animation controller, `models.js`, and LAN networking code.

## Required runtime dependencies not physically bundled in this archive

The current `libs/` folder does not contain the required Three.js runtime or its loader dependencies. Android Gradle tasks already attempt to fetch Three.js r128 (required) and the r128 FBX/GLTF loaders and `fflate` (optional). Internet access is required on the build computer for those downloads. `three.min.js` is deliberately not replaced with a fake or empty file.

## Animation gaps

The project includes idle/run/jump animation FBX files only. No compatible shooting, death, or reload animation FBX files were found in the supplied project. A public CC0 source for additional humanoid animations is Quaternius' Universal Animation Library:
- https://quaternius.com/packs/universalanimationlibrary.html
- https://github.com/J-Ponzo/gltf-universal-animation-library

Those clips use a universal humanoid rig. They must be checked/retargeted to the bundled Kenney character rig before being connected to gameplay; simply copying them does not guarantee correct animation.

## Build-time download (no Python required)

On a PC with internet access, open the project in Android Studio and run **Build > Rebuild Project**. The Gradle `preBuild` hook fetches Three.js r128 and optional loader files. To explicitly retry the dependencies from a terminal in the project root:

- Windows: `gradlew.bat downloadThreeJs downloadOptionalLibs downloadSoldierModels`
- macOS/Linux: `./gradlew downloadThreeJs downloadOptionalLibs downloadSoldierModels`

The offline single-player game must remain usable when optional models fail to load; the existing procedural fallback is retained. A successful Gradle build is not proof that animations are wired or that LAN multiplayer works. Test on physical Android devices before release.

## Multiplayer status

`js/netplay.js` and network documentation are present, but this archive has not been validated as a completed, fully synchronized LAN multiplayer game. Combat/health, loot, vehicles, safe-zone phases, scoring and reconnect handling need integration verification and physical-device tests. Preserve offline single-player while fixing LAN play.
