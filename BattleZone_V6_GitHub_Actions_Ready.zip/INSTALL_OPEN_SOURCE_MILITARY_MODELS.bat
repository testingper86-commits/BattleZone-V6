@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul && (set PY=python) || (set PY=py -3)
%PY% install_open_source_military_models.py
if errorlevel 1 (
  echo.
  echo Model download failed. Check internet access and Python 3.
  pause
  exit /b 1
)
echo.
echo Source model assets downloaded. Read MILITARY_CHARACTER_ASSETS.md before rebuilding.
pause
