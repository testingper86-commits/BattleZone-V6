# Black-screen fix (what changed)
Root cause: the game's only hard dependency, Three.js r128 (`libs/three.min.js`), was not in the package,
and failures (missing/wrong file, no WebGL, script crash) were silent -> black screen with only the HTML HUD.

1. app/build.gradle.kts: task `downloadThreeJs` (hooked to preBuild) downloads + validates r128 from 3 mirrors,
   and replaces a wrong file (backup: three.min.js.replaced-backup).
2. index.html bootstrap: full-screen diagnostic panel for missing file / non-classic build / no WebGL /
   GPU context lost / renderer never drew a frame (7 s watchdog). Compat layer for r152-r159.
3. MainActivity.kt: JS errors go to Logcat as Log.e (tag BattleZoneWeb); correct MIME types; WebView
   crash -> auto-recreate; chrome://inspect enabled on debug builds; HTTP errors logged.
4. Voice lines: bundled voicepacks looked up first (removes 3 failed requests per line).
5. gradle/wrapper/gradle-wrapper.properties added (Gradle 8.9, required by AGP 8.7).
6. Manifest: hardwareAccelerated=true.

## v2 additions
7. LAN match layer (www/js/netplay.js): host-authoritative hits/health/kills/score/match end, team assignment, HUD,
   "host started" auto-start, forged-event rejection. Verified with a two-instance simulated bridge (15 checks).
8. Remote avatars now face the right way (were rotated 180 degrees) and are no longer disposed twice.
9. Optional rigged soldier model for remote players (www/js/models.js + GLTFLoader/SkeletonUtils r128, soldier.glb), fetched by Gradle;
   falls back to procedural avatars. NOT verified against the real soldier.glb (orientation: CFG.yawOffset in models.js).
10. Kotlin: client `connected` status now carries room mode/maxPlayers.

## v4 additions
11. LAN bots (host-simulated) that fill empty slots and attack remote players; bot avatars on clients; tested in simulation.
12. FBX/GLB model loader driven by models/characters/manifest.json (Kenney layout by default); Gradle fetches FBXLoader, fflate,
    GLTFLoader, SkeletonUtils r128. See models/characters/README.md. FEATURE_STATUS.md lists what is and is not done.

## v5
13. Real Kenney pack installed (models/characters/kenney). Loader fixed for its real layout: skips the static "Targeting Pose" clip,
    4 skins, idle/run/jump, walk = slowed run. Model now dresses the local player, bots/allies and remote avatars.
14. The uploaded FBXLoader.js is the ES-module build (needs modern Three.js) and is NOT used; Gradle fetches the r128 classic loader.

## v6
15. setup_assets.py / SETUP_ASSETS.bat / setup_assets.sh: one-click download + verification of all required open-source libs.
16. Gradle version check now compares the exact REVISION number; NURBS helpers added for FBXLoader; soldier.glb download is manual-only.
17. Held gun mesh on FBX bodies (local third-person + remote players).
