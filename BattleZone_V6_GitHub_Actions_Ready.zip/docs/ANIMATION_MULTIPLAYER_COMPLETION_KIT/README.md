# Battle Zone V6 — Animation & Multiplayer Completion Kit

This kit is added to the Battle Zone V6 Recovery Package. It is **integration scaffolding, not a claim that all features are finished**. The original project and existing networking code are preserved.

## Character animations

Added: `app/src/main/assets/www/js/animation/character-animation-controller.js`

This helper uses Three.js `AnimationMixer` and finds clips by name (idle, run, shoot/fire, reload, death/die). You must obtain compatible animation clips for the actual character skeleton, check their licences, and retarget them if needed. The helper deliberately does not fabricate animation assets. Load the helper after Three.js and integrate it where the game's character model and animation clips are loaded. Call `controller.update(deltaSeconds)` every render frame. Check `controller.available()` to see which clip names were found.

Before wiring it into gameplay, confirm the project actually loads a skinned GLTF/FBX character and its clips; the current HTML may use procedural character effects rather than a rigged model. Do not include the helper script until the integration point is verified.

## Multiplayer

Read the existing `NETWORK_PROTOCOL.md`, `MULTIPLAYER_DISCOVERY_FIX.md`, and `js/netplay.js` first. Keep the existing LAN flow if local-only multiplayer is the goal. A remote authoritative server is a separate architecture and cannot be enabled by merely adding client code.

Required authority rules:
- Clients send input/intent; host/server validates movement limits and fire rate.
- Host/server resolves hit detection, health, death/respawn, loot ownership and safe-zone damage.
- Vehicle driver inputs are authoritative; other clients receive replicated vehicle transforms/state.
- Use stable player/entity IDs, sequence numbers and timestamps; reject stale/duplicate messages.
- Do not trust client-reported damage, inventory, kills or zone damage.

## Device test checklist

1. Install the same build on two physical Android devices.
2. Join/leave repeatedly; verify no ghost players remain.
3. Move/turn and check remote interpolation without excessive jitter.
4. Fire at the same target from both clients; verify one authoritative damage result.
5. Reload while moving, fire during reload, die while reloading, then respawn.
6. Pick up the same loot simultaneously; exactly one player must receive it.
7. Drive/enter/exit vehicles; all clients must agree on driver and vehicle state.
8. Advance the safe-zone timer on both devices; verify matching boundary and damage.
9. Test packet delay/loss, background/resume, Wi-Fi change, and host disconnect.
10. Repeat on low-end Android hardware and record crashes, FPS and network logs.

## Status

- Helper source added: yes.
- Compatible animation binaries included: no — source character rig and licensing must be verified first.
- Animation helper wired into the main game loop: no — the exact model-loading point must be verified.
- Multiplayer feature completion/device validation: not claimed; run the checklist above.
