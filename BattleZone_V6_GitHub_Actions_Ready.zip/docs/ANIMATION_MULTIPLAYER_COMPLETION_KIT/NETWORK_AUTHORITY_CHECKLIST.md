# Server/host authority checklist

Use this as acceptance criteria while integrating the existing LAN networking implementation.

| State | Authoritative owner | Replicated state |
|---|---|---|
| Player motion | Host/server validates movement | position, rotation, velocity, sequence |
| Shooting | Host/server validates weapon, ammo and fire cadence | shot event, hit result, ammo |
| Health/death | Host/server | health, dead flag, death/respawn event |
| Reload | Server/host validates ammo and reload duration | reload start/end and ammo count |
| Safe zone | Host/server | center, radius, phase, deadline |
| Loot | Host/server | entity ID, item type, position, claimed status |
| Vehicles | Host/server validates driver/input | transform, health, driver/passenger IDs |

Do not mix clocks from devices for game rules. Use host/server time and monotonically increasing sequence numbers. For local LAN host migration, explicitly define who becomes host and how authoritative state is transferred; otherwise terminate the match cleanly if the host disappears.
