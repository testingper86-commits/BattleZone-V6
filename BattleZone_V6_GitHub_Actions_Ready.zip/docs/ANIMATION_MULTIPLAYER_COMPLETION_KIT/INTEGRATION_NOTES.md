# Integration notes

1. Verify the actual character model format, skeleton, current animation clips, and Three.js version before selecting assets.
2. Obtain shooting, reload and death clips licensed for redistribution/use; retarget to the exact rig and preview before bundling.
3. Load `character-animation-controller.js` only after Three.js is available. Instantiate it with the model and `gltf.animations` (or equivalent clips).
4. Call `update(delta)` once per render frame; call `shoot()`, `reload()`, and `die()` from validated gameplay state transitions.
5. On multiplayer, replicate animation state/event IDs, not raw animation frame values. Local clients can interpolate cosmetic playback, while health/death and ammo remain authoritative.
6. Validate offline mode still works when no multiplayer room is joined.
7. Run `validate_project.py`, build the Android app, and test two physical devices. Passing a source-level checklist does not prove runtime correctness.
