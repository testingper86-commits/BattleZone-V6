# Battle Zone — Collision, Landing, Weather and Character Polish

## Changes in this patch
- Reworked player collision resolution to iteratively push out of overlapping obstacle bounds and use movement substeps, reducing rock/building tunnelling and corner traps.
- Registered more of the visible rock field as conservative collision obstacles.
- Switched the player to a visible third-person character after landing and enabled the player model when a match starts, so the landing transition is easier to read.
- Added map-specific weather-front pools (jungle, island, canyon, harbor, highland, wasteland and marsh) and kept the existing weather target interpolation smooth. The environment updates continuously and weather fronts change on a timer; it does not switch to a completely different weather preset every literal second because that would cause visual flicker.
- Improved eye detail and head proportions in the procedural character model.

## Validation
- JavaScript syntax check passed for all 8 inline script blocks using `node --check`.
- ZIP integrity check passed after packaging.
- Not tested on a physical Android device or in a live gameplay session in this environment. Collision shapes are still approximate AABBs, not mesh-accurate physics; procedural characters are improved but not equivalent to a professionally rigged/animated 3D character asset. Smooth loading and device-specific rendering still require on-device profiling.

## Android Studio
Open the project folder in Android Studio. If the bundled Three.js asset is missing from `app/src/main/assets/www/libs/three.min.js`, run `python download_threejs.py` on a computer with internet access before building.
