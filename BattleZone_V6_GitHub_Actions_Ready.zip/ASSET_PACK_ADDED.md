# Battle Zone asset pack update

Added to `app/src/main/assets/www/`:
- `branding/battle_zone_logo.jpg`: custom Battle Zone logo/key-art concept image.
- `branding/battle_zone_app_icon_concept.jpg`: app icon concept artwork.
- `loading/boot_scene_1.jpg` through `boot_scene_3.jpg`: offline cinematic loading backgrounds.
- `characters/portraits/`: 17 character portrait-card images for roster/shop use and future UI integration.
- `audio/voicepacks/<character>/line_1.mp3` through `line_3.mp3`: 51 locally generated synthetic English radio-callout demo clips, with voice variation by character.

The game now displays a randomized loading splash on initial page load and randomizes the scene/title when starting a match. Character shop cards have a Voice pack demo button that plays a random line for the selected character.

Important limitations:
- The voice clips are synthetic placeholder callouts, not professional human-recorded performances or a complete localized voice acting set.
- The portrait images are 2D artwork. They do not replace the game's low-detail 3D player meshes with fully rigged, realistic 3D character models. That requires original GLB/GLTF/FBX models, PBR textures, skeletons, animations, and model integration.
- These changes were syntax-checked and the archive was checked for integrity; no physical Android device test or full Gradle build was performed here.
- The existing project expects the Three.js runtime at `app/src/main/assets/www/libs/three.min.js`; this ZIP preserves the source project's existing library setup and does not bundle that third-party runtime file.
