@echo off
setlocal
set "ROOT=%~dp0"
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle -p "%ROOT%" %*
  exit /b %errorlevel%
)
set "GV=8.9"
set "CACHE=%USERPROFILE%\.gradle\battlezone-bootstrap\gradle-%GV%"
set "BIN=%CACHE%\bin\gradle.bat"
if not exist "%BIN%" (
  set "ZIP=%TEMP%\battlezone-gradle-%GV%.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GV%-bin.zip' -OutFile '%TEMP%\battlezone-gradle-%GV%.zip'; Expand-Archive -Force '%TEMP%\battlezone-gradle-%GV%.zip' '%USERPROFILE%\.gradle\battlezone-bootstrap'; Remove-Item '%TEMP%\battlezone-gradle-%GV%.zip'"
  if errorlevel 1 exit /b %errorlevel%
)
call "%BIN%" -p "%ROOT%" %*
exit /b %errorlevel%
