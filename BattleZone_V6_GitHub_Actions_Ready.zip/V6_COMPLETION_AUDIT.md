# Battle Zone V6 — Completion Audit and Recovery Instructions

## Important status
This package is **not certified as a completed release**. The source ZIP was prepared in an environment without outbound DNS/network access, so the official Three.js binary could not be downloaded and embedded here. No fake/empty library or fabricated model/animation files were added.

## Dependency setup (requires internet once)
1. Run `PREPARE_COMPLETE_BUILD.bat` on Windows, or `python3 setup_assets.py` on a computer with internet access.
2. The setup script downloads and size/version-checks the Three.js r128 classic build and compatible r128 classic loaders from official package mirrors.
3. Open the project in Android Studio (JDK 17 and Android SDK required), sync Gradle, then run `:app:assembleDebug`.
4. Verify `app/src/main/assets/www/libs/three.min.js` exists and contains the r128 revision before testing.
5. Install the debug APK on a physical Android device, then test with internet disabled.

## Asset audit
Bundled character assets in the original V6 source include:
- `models/characters/kenney/Model/characterMedium.fbx`
- `models/characters/kenney/Animations/idle.fbx`
- `models/characters/kenney/Animations/run.fbx`
- `models/characters/kenney/Animations/jump.fbx`
- Multiple skin textures under `models/characters/kenney/Skins/`

Not found as dedicated bundled clips in the inspected V6 source:
- Shooting animation
- Death/elimination animation
- Reload animation

Do not rename idle/run/jump clips to imply that they are shooting, death, or reload clips. These animations must be obtained from a compatible licensed source and tested against the exact skeleton, or implemented and validated on the rig.

## Code-level features still requiring verification/implementation
- Server/host-authoritative hit validation, damage, elimination, scoring, and complete match-state synchronization.
- Battle royale synchronization for safe zone, zone damage, vehicles, loot, and win conditions.
- Reconnect/resume and host migration behavior.
- Collision tests for buildings/rocks, bullet occlusion by walls, vehicle entry/drive/exit, airborne/vehicle loot restrictions, bot line-of-sight and movement.
- Lobby 3D preview and all character/skin loading paths.
- Physical Android tests for 2/4/8 players, disconnects, latency, hotspot behavior, and offline operation.

The project contains source code and documentation for several of these systems, but source presence alone does not prove runtime correctness.

## No placeholder policy
No zero-byte or fake Three.js, FBX, model, or animation files should be used. If a required asset cannot be obtained, keep the issue visible and fail validation rather than claiming it is complete.
