@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul && (set PY=python) || (set PY=py -3)
%PY% install_open_source_voice_pack.py
if errorlevel 1 (
 echo Voice pack installation failed. Check internet connection and Python installation.
) else (
 echo Voice pack installed. Rebuild the Android app to bundle offline audio.
)
pause
