# Open-source voice pack integration

This project uses Kenney's Voiceover Pack, licensed CC0. Source: https://kenney.nl/assets/voiceover-pack (also listed at https://opengameart.org/content/voiceover-pack-40-lines).

## Install the actual audio files
1. On a computer with Python 3 and internet access, open this project folder.
2. Run `INSTALL_OPEN_SOURCE_VOICE_PACK.bat`.
3. Rebuild the Android app so the downloaded clips are packaged in the app assets.

The installer downloads the CC0 archive, finds the available generic callouts, and copies local audio files into `app/src/main/assets/www/audio/open_source_voice/`. The same generic callouts are assigned to each operator; these are not unique actor performances for each character. Check `voice_manifest.csv` after installation.

This environment could not download binary archives directly, so the actual CC0 clips are not bundled in this ZIP yet. The installer performs that step on your PC.
