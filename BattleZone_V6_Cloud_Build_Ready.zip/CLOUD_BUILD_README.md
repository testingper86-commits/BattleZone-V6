# BattleZone V6 — Cloud APK build

This is the BattleZone Android project with a GitHub Actions workflow added for building a debug APK without opening Android Studio.

## Build in the cloud

1. Create a GitHub repository.
2. Extract this ZIP and upload the **contents of this folder** to the repository root (so `settings.gradle.kts`, `build.gradle.kts`, `app/`, `gradle/`, and `.github/` are at the repository root).
3. In GitHub, open **Actions** → **BattleZone Android APK**.
4. Choose **Run workflow** (or push to the `main` branch).
5. When the run finishes, open the run's **Artifacts** section and download `BattleZone-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

## Build notes

- This workflow uses JDK 17, Gradle 8.9, Android SDK platform 35, and build tools 35.0.0.
- The app's Gradle build script downloads Three.js r128 and optional loader files during `preBuild`. The build runner needs network access.
- The APK is a **debug APK** for testing, not a signed release APK for Play Store publication.
- A successful cloud compile does not prove gameplay or multiplayer works correctly. Test the APK on a real device, including offline launch and LAN multiplayer.
- No APK is included in this ZIP; the APK is produced only after the GitHub Actions workflow runs successfully.
