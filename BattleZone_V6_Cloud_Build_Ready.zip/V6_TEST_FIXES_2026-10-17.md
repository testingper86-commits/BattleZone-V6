# BattleZone V6 — Test-driven hotfix package

Date: 2026-10-17

## Changes applied to `app/src/main/assets/www/index.html`

1. RUN button now uses press-and-hold behavior rather than toggling sprint state on each tap.
2. Disabled the delayed startup loading overlay that appeared after the lobby was already visible. Match-start and map-transition loading remain available.
3. Corrected safe-zone intermission indexing so each completed shrink uses that phase's configured wait time. The existing five-entry `ZONE_PHASES` sequence remains intact.
4. Increased the oak-tree collision footprint and retained those trees in the environment effects list, reducing the chance of a player clipping into a tree.
5. Added an airborne HUD state: combat and utility controls are hidden during plane/drop/dive phases while the movement stick and phase-specific jump/parachute action remain available.
6. Suppressed the character's running animation while airborne.
7. Moved the local multiplayer entry away from the top-right currency area and hid the entry during a match; the room panel remains a separate lobby-only entry point.
8. Added responsive lobby sizing for narrow phone screens and safe-area spacing.

## Verification

- Checked all inline JavaScript blocks with `node --check`; no syntax errors were reported after patching.
- The Android APK has **not** been rebuilt or runtime-tested in this package. Upload this ZIP to the existing GitHub repository to trigger its cloud build, then install and retest the resulting APK.
- This is a focused hotfix, not a claim that every lobby layout issue, character scale issue, multiplayer synchronization issue, or all five zone phases have been fully validated on-device. Those still need device retesting and screenshots when available.
