# Manual Test Checklist

No automated instrumented test suite ships with this project — building and verifying real
Espresso/JUnit tests requires a connected device/emulator and a Gradle test run, neither of
which is available in the environment this code was written in. This checklist is the honest
substitute: run through it on a real device before you trust a release build.

Do this with the device's Wi-Fi and mobile data both turned off, to confirm requirement
"core file management must work without internet" and "offline testing with network access
disabled."

## Core file management
- [ ] Browse internal storage; open several folders deep, then back out with the back arrow
- [ ] If an SD card or USB OTG drive is available, confirm it's visible and browsable
- [ ] Create a folder, rename it, move it, delete it (goes to Recycle Bin), restore it
- [ ] Multi-select 3+ files; batch rename with a `{n}` pattern; verify the numbering
- [ ] Copy a file into a folder that already has a same-named file — confirm it does not
      silently overwrite (should auto-rename or prompt)
- [ ] Search by partial name; search by extension
- [ ] Sort by name, date, size, type — ascending and descending
- [ ] Toggle List view ↔ Grid view from the header menu
- [ ] Toggle "Show hidden files" and confirm dotfiles appear/disappear
- [ ] Trigger a large copy (several hundred MB) and confirm a progress indicator shows and
      the UI stays responsive (scroll elsewhere while it runs)

## Previews
- [ ] Open a JPEG/PNG — pinch to zoom
- [ ] Play an MP4 and an MP3 to completion
- [ ] Open a plain-text file, edit it, save, reopen to confirm the edit persisted
- [ ] Open a PDF
- [ ] Tap an APK — confirm it shows package info without launching the installer
- [ ] Open a file type with no built-in viewer (e.g. `.docx`) — confirm "Open with…" offers
      installed apps

## Archives
- [ ] Select several files, "Compress to ZIP", confirm the resulting zip opens elsewhere
- [ ] Browse a ZIP's contents without extracting
- [ ] Extract one entry from a ZIP, then extract all
- [ ] Extract a ZIP crafted with a `../../` path in an entry name — confirm it is rejected,
      not extracted outside the destination folder (zip-slip protection)
- [ ] Try extracting a deliberately corrupted/truncated ZIP — confirm a clean error, not a crash

## Storage analysis
- [ ] Home screen shows total/used/free storage correctly
- [ ] "Largest files" lists real files sorted biggest-first
- [ ] "Find duplicate files" — plant two identical files in different folders first, confirm
      they're grouped together, and a different file of the same size but different content
      is NOT grouped with them
- [ ] Use "Move all but the oldest copy to Recycle Bin" and confirm only one copy remains
      locally and the rest are restorable from Recycle Bin

## Recycle Bin
- [ ] Delete a file, confirm it disappears from its folder and appears in Recycle Bin
- [ ] Restore it, confirm it returns to its original folder
- [ ] Delete something, delete its original parent folder entirely, then try Restore —
      confirm it falls back to internal storage with a clear message instead of crashing
- [ ] Empty Recycle Bin, confirm the confirmation dialog appears and wording is accurate

## Vault
- [ ] Set a Vault PIN, move a file in, close the app fully, reopen, confirm Open Vault asks
      for the PIN again every time (it should never stay unlocked across a restart)
- [ ] Enter the wrong PIN — confirm it's rejected with a clear message
- [ ] Move a file out of the Vault, confirm it reappears in its original folder (or internal
      storage root if that folder is gone)

## App Lock
- [ ] Set an App Lock PIN, enable "Require unlock to open app"
- [ ] Put the app in the background (Home button), return to it — confirm the lock screen
      appears before any content is visible
- [ ] On a device with fingerprint/face unlock enrolled, confirm the biometric prompt appears
      automatically and "Use PIN" falls back correctly
- [ ] Disable App Lock, confirm the app opens straight to Home afterward

## Permissions
- [ ] Deny "All files access" when first prompted — confirm the app explains what's needed
      rather than silently showing an empty list
- [ ] Grant it from Settings afterward and confirm the app recovers without a restart

## Wi-Fi transfer (needs two devices on the same Wi-Fi network)
- [ ] On device A: Settings → Receive via Wi-Fi, note the IP:port it shows
- [ ] On device B: select a file → ⋮ → Send via Wi-Fi…, enter device A's IP
- [ ] Confirm device A shows an Accept/Decline prompt with file count and size — nothing
      should transfer before you tap Accept
- [ ] Accept it, confirm the file arrives in device A's Download/LanReceived folder and opens
      correctly (verifies the checksum check passed silently)
- [ ] Repeat but tap Decline on device A — confirm device B is told the transfer was declined,
      not left hanging or shown a confusing error
- [ ] Start a transfer, then force-close the receiving app mid-transfer — confirm the sender
      reports a failure rather than hanging indefinitely
- [ ] Try sending with the two devices on different networks (e.g. one on Wi-Fi, one on mobile
      data) — confirm it fails with a clear connection error rather than a crash

## Performance
- [ ] Open a folder with 1,000+ files — confirm scrolling stays smooth (list is backed by a
      real recycled `ListView`/`BaseAdapter`, not one view per file)
- [ ] Repeat the above in Grid view
- [ ] If you have access to a genuinely low-end/low-RAM device, confirm background blur is
      automatically disabled there (`ActivityManager.isLowRamDevice()`), and that you can
      still toggle blur manually in Settings on a normal device
