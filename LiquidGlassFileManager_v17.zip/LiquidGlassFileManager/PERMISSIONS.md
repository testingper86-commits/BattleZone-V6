# Permissions and Device Limitations

## Permissions this app requests, and why

| Permission | Why |
|---|---|
| `MANAGE_EXTERNAL_STORAGE` | Lets the app browse and manage files anywhere on shared storage, not just its own app-specific folder. This is the broadest storage permission Android offers; the app only reads/writes files the user explicitly navigates to or acts on. |
| `READ_EXTERNAL_STORAGE` (API ≤ 32) | Fallback for older Android versions where `MANAGE_EXTERNAL_STORAGE` isn't the primary model yet. |
| `WRITE_EXTERNAL_STORAGE` (API ≤ 29) | Same — pre-scoped-storage fallback. |
| `REQUEST_INSTALL_PACKAGES` | Needed to show "install" as an action when the user taps an APK. The app never installs anything without the user tapping that action themselves — Android's own installer UI still runs the actual install and asks for confirmation. |
| `INTERNET` | Added for the "Send/Receive via Wi-Fi" feature. Android requires this permission for any raw socket use, even when every byte stays on the local Wi-Fi network and never reaches the open internet — the OS doesn't distinguish by destination. This app makes no other network call of any kind: no analytics, no ads, no update checks, no telemetry. |

No contacts, location, camera, microphone, or SMS permission is requested, and none is
needed for anything this app does.

## What this app does **not** do
- It does not upload, sync, or transmit your files anywhere. There is no server component.
- It does not read files outside what the Android storage permission model grants it.
- It does not request advertising or analytics permissions, because it has no ads or
  analytics.

## Known device limitations (be honest about these, don't paper over them)
- **System-managed folders** (e.g. `/Android/data/<package>/` for most other apps, and most
  of `/Android/obb/`) are off-limits even with `MANAGE_EXTERNAL_STORAGE`, by Android's own
  scoped-storage rules starting with Android 11. This is a platform restriction, not a bug
  in this app — no file manager can bypass it on an unrooted device.
- **Deleted files are not always recoverable.** The Recycle Bin only catches files deleted
  *through this app's own delete action*. A file deleted by another app, removed by the
  system, or permanently purged from the Recycle Bin (manually, or automatically after the
  retention period) cannot be recovered by this app.
- **The Vault is a hiding mechanism, not encryption.** Vault files are moved into this app's
  private storage and gated by a PIN, which stops casual access from the file manager UI and
  from other normal apps. It does **not** protect against someone with root access, ADB
  access, or a full device backup — those can still read the underlying bytes. This is stated
  in-app as well; it should never be marketed as "encrypted" without adding real file-content
  encryption (e.g. AES via the Android Keystore), which this build does not include.
- **Biometric unlock** uses the platform `BiometricPrompt` API (Android 9+/API 28+) with no
  extra library dependency. On older devices, or devices with no biometric hardware/enrollment,
  App Lock silently falls back to PIN-only — this is expected, not a bug.
- **Duplicate detection** is exact-match only (same size, then same SHA-256 checksum). It will
  not find near-duplicates, resized copies of the same photo, or re-encoded videos.
- **RAR and 7z archives** are not supported for browse/extract in this build — only ZIP.
  Adding them means pulling in a third-party archive library, which was deliberately left out
  of this pass rather than added without the ability to verify it actually builds and
  resolves correctly offline.
- **Wi-Fi transfer** (Settings → Send/Receive via Wi-Fi) is implemented as a deliberately
  minimal raw-socket protocol: both devices must be on the same Wi-Fi network, the sender
  types in the receiver's IP address (shown on the receiver's own screen — no discovery, no
  QR code), the receiver must explicitly accept before any bytes are sent, and every file is
  checksum-verified (SHA-256) after transfer. There is no pause/resume — a dropped connection
  means starting that transfer over. This has not been tested across two real devices (this
  build environment has none); the protocol logic has only been reasoned through, not run.
- **Bluetooth** is not a separate implementation — sharing can still go out through Android's
  standard share sheet (`ACTION_SEND`) to whatever Bluetooth/Nearby Share app is installed,
  but there is no dedicated in-app Bluetooth transfer.
