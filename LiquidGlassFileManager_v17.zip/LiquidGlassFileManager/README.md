# Liquid Glass Files  (v3.0)

1. Android Studio → File → Open → select this folder. Use **Gradle JDK 17–21** (Settings → Build Tools → Gradle).
2. Wait for Gradle sync, then press Run ▶ (Android 8.0 / API 26+).
3. On first launch grant "All files access".

Built-in viewers: images (pinch-zoom, swipe buttons), video, audio, PDF, text, ZIP (browse + extract).
APK files install; other types open with the installed app. Categories, global search, Favorites, Settings, About.
