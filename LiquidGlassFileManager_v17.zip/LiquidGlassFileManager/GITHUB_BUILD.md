# Building via GitHub (no laptop needed)

This repo includes `.github/workflows/build.yml`. Once the code is in a GitHub repo, every
push automatically builds a debug APK you can download from your phone — no local Android
SDK, no laptop, ever.

## Step 1 — Get the code into a GitHub repo (one-time, needs *some* way to run a terminal)

You still need one path to get these files into a repo the first time. From a phone, the
most realistic option is **GitHub Codespaces**, which runs entirely in a mobile browser:

1. On github.com (mobile browser is fine), create a new empty repository.
2. Open it, tap the green **Code** button → **Codespaces** tab → **Create codespace on main**.
3. This opens a full VS Code instance in your browser, with a terminal.
4. In the Codespace's file explorer, use **Upload...** (or drag-and-drop if your browser
   supports it) to upload the `LiquidGlassFileManager_v16.zip` file itself.
5. In the Codespace terminal:
   ```
   unzip LiquidGlassFileManager_v16.zip -d .
   mv LiquidGlassFileManager/* LiquidGlassFileManager/.github . 2>/dev/null
   mv LiquidGlassFileManager/.[!.]* . 2>/dev/null
   rm -rf LiquidGlassFileManager LiquidGlassFileManager_v16.zip
   git add -A
   git commit -m "Initial import"
   git push
   ```
   (The `mv` commands flatten the zip's inner folder so `build.gradle`/`settings.gradle`
   end up at the repo root, which Gradle expects — check with `ls` that `build.gradle` is
   directly visible before committing, adjust the paths above if your zip's folder name
   differs.)

If you ever do get occasional access to any computer (library, friend's laptop, internet
café), this step is also a 30-second `git init && git add -A && git commit && git push` —
only step 1 ever needs that; everything after is phone-only.

## Step 2 — Let Actions build it
Pushing in step 1 already triggers the workflow. To re-run without a new push: on GitHub
(mobile browser or the GitHub mobile app both work) → your repo → **Actions** tab → **Build
APK** → **Run workflow**.

## Step 3 — Download the APK, from your phone
Actions tab → the latest run → scroll to **Artifacts** → tap `app-debug-apk` → it downloads
a zip containing `app-debug.apk`. Android will offer to install it directly (you'll need to
allow "install unknown apps" for whichever app you downloaded it through, same as any
sideloaded APK).

## Signed release build (optional, only once you're ready to publish)
The debug APK above is enough to test on your own phone. For a signed release build through
Actions too:
1. Generate a keystore and add the `signingConfigs` block to `app/build.gradle` — exact
   commands are in `RELEASE.md`. This has to be done once in the repo; the workflow can't
   invent a signing key for you.
2. Base64-encode the keystore file (`base64 release-key.jks`, or an online base64 encoder if
   you're doing this from a phone with no terminal).
3. In the GitHub repo: **Settings → Secrets and variables → Actions → New repository
   secret**, add four secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`,
   `KEY_PASSWORD`.
4. Push again (or re-run the workflow) — the release-signing steps in `build.yml` are
   skipped automatically when these secrets aren't set, and run automatically once they are.

## Honest limitation
This workflow file has been written carefully but **not actually run** — there's no GitHub
Actions runner available in the environment this was built in to verify it end-to-end. The
steps and action versions are current as of this writing, but if the first run fails, the
error log in the Actions tab is the most useful next thing to share.
