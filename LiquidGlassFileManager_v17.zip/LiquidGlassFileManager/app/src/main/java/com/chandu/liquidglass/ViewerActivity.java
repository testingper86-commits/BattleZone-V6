package com.chandu.liquidglass;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.LruCache;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Built-in viewer: images (pinch zoom), video, audio, PDF and text. Works without any other app installed. */
public class ViewerActivity extends Activity {
    ArrayList<String> paths;
    int idx;
    FrameLayout root, stage;
    TextView titleTv, counterTv;
    ImageView prevBtn, nextBtn;
    LinearLayout bar;
    final ExecutorService io = Executors.newSingleThreadExecutor();
    final Handler h = new Handler(Looper.getMainLooper());
    MediaPlayer mp;
    VideoView vv;
    PdfRenderer pdf;
    ParcelFileDescriptor pfd;
    Runnable ticker;
    boolean destroyed;
    int topInset, bottomInset;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        paths = getIntent().getStringArrayListExtra("paths");
        idx = getIntent().getIntExtra("index", 0);
        if (paths == null || paths.isEmpty()) { finish(); return; }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070C);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));

        bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.glass(26, true));
        bar.setPadding(Ui.dp(4), 0, Ui.dp(4), 0);
        ImageView back = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        back.setOnClickListener(v -> finish());
        titleTv = Ui.tv(this, "", 15, Ui.WHITE, true);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        counterTv = Ui.tv(this, "", 12, Ui.SUB, false);
        ImageView open = Ui.iconBtn(this, Glyphs.OPEN, Ui.WHITE);
        open.setOnClickListener(v -> FileOps.external(this, new File(paths.get(idx)), true));
        ImageView share = Ui.iconBtn(this, Glyphs.SHARE, Ui.WHITE);
        share.setOnClickListener(v -> { ArrayList<File> l = new ArrayList<>(); l.add(new File(paths.get(idx))); FileOps.share(this, l); });
        bar.addView(back, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        bar.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.rightMargin = Ui.dp(6);
        bar.addView(counterTv, cl);
        bar.addView(open, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        bar.addView(share, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, Ui.dp(52), Gravity.TOP);
        bp.setMargins(Ui.dp(12), Ui.dp(8), Ui.dp(12), 0);
        root.addView(bar, bp);

        prevBtn = edge(Glyphs.BACK, Gravity.START | Gravity.CENTER_VERTICAL, -1);
        nextBtn = edge(Glyphs.NEXT, Gravity.END | Gravity.CENTER_VERTICAL, 1);

        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets in = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                topInset = in.top; bottomInset = in.bottom;
            } else { topInset = insets.getSystemWindowInsetTop(); bottomInset = insets.getSystemWindowInsetBottom(); }
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) bar.getLayoutParams();
            if (p.topMargin != topInset + Ui.dp(8)) { p.topMargin = topInset + Ui.dp(8); bar.setLayoutParams(p); }
            return insets;
        });
        root.requestApplyInsets();
        show();
    }

    ImageView edge(int glyph, int gravity, final int delta) {
        ImageView v = new ImageView(this);
        v.setImageDrawable(Glyphs.get(glyph, Ui.WHITE));
        v.setBackground(Ui.glass(24, true));
        v.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        v.setOnClickListener(x -> go(delta));
        Ui.press(v);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(46), Ui.dp(46), gravity);
        p.setMargins(Ui.dp(10), 0, Ui.dp(10), 0);
        root.addView(v, p);
        return v;
    }

    void go(int d) {
        int n = idx + d;
        if (n < 0 || n >= paths.size()) return;
        idx = n;
        show();
    }

    void cleanup() {
        if (ticker != null) { h.removeCallbacks(ticker); ticker = null; }
        if (mp != null) { try { mp.release(); } catch (Exception ignored) { } mp = null; }
        if (vv != null) { try { vv.stopPlayback(); } catch (Exception ignored) { } vv = null; }
        if (pdf != null) {
            final PdfRenderer r = pdf;
            final ParcelFileDescriptor f = pfd;
            io.execute(() -> { try { r.close(); } catch (Exception ignored) { } try { if (f != null) f.close(); } catch (Exception ignored) { } });
            pdf = null; pfd = null;
        }
        stage.removeAllViews();
    }

    void show() {
        cleanup();
        File f = new File(paths.get(idx));
        Entry e = new Entry(f);
        titleTv.setText(f.getName());
        counterTv.setText(paths.size() > 1 ? (idx + 1) + "/" + paths.size() : "");
        boolean multi = paths.size() > 1 && (e.kind == FileKinds.IMAGE || e.kind == FileKinds.VIDEO);
        prevBtn.setVisibility(multi && idx > 0 ? View.VISIBLE : View.GONE);
        nextBtn.setVisibility(multi && idx < paths.size() - 1 ? View.VISIBLE : View.GONE);
        switch (e.kind) {
            case FileKinds.IMAGE: showImage(f); break;
            case FileKinds.VIDEO: showVideo(f); break;
            case FileKinds.AUDIO: showAudio(f, e); break;
            case FileKinds.PDF: showPdf(f); break;
            default: showText(f);
        }
        bar.bringToFront();
        prevBtn.bringToFront();
        nextBtn.bringToFront();
    }

    // ---------------- image ----------------
    void showImage(final File f) {
        final ZoomImage z = new ZoomImage(this);
        stage.addView(z, new FrameLayout.LayoutParams(-1, -1));
        final int my = idx;
        io.execute(() -> {
            final Bitmap bm = decode(f, 2600);
            h.post(() -> {
                if (destroyed || my != idx) return;
                if (bm == null) Ui.toast(this, "Can't display this image");
                else z.setImageBitmap(bm);
            });
        });
    }

    static Bitmap decode(File f, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > max) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            if (b == null) return null;
            int rot = 0;
            try {
                int ori = new ExifInterface(f.getAbsolutePath()).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            } catch (Exception ignored) { }
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    static final class ZoomImage extends ImageView {
        final Matrix m = new Matrix();
        final ScaleGestureDetector sg;
        final GestureDetector gd;
        float minS = 1f;

        ZoomImage(android.content.Context c) {
            super(c);
            setScaleType(ScaleType.MATRIX);
            sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    float cur = scale();
                    float ns = Math.max(minS, Math.min(cur * d.getScaleFactor(), minS * 8f));
                    float f = ns / cur;
                    m.postScale(f, f, d.getFocusX(), d.getFocusY());
                    fix();
                    setImageMatrix(m);
                    return true;
                }
            });
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                    m.postTranslate(-dx, -dy);
                    fix();
                    setImageMatrix(m);
                    return true;
                }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    float cur = scale();
                    float target = cur > minS * 1.5f ? minS : minS * 3f;
                    float f = target / cur;
                    m.postScale(f, f, e.getX(), e.getY());
                    fix();
                    setImageMatrix(m);
                    return true;
                }
            });
        }

        float scale() { float[] v = new float[9]; m.getValues(v); return v[Matrix.MSCALE_X]; }

        void fit() {
            Drawable d = getDrawable();
            if (d == null || getWidth() == 0) return;
            float dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
            float s = Math.min(getWidth() / dw, getHeight() / dh);
            minS = s;
            m.reset();
            m.postScale(s, s);
            m.postTranslate((getWidth() - dw * s) / 2f, (getHeight() - dh * s) / 2f);
            setImageMatrix(m);
        }

        void fix() {
            Drawable d = getDrawable();
            if (d == null) return;
            RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
            m.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = (getWidth() - r.width()) / 2f - r.left;
            else if (r.left > 0) dx = -r.left;
            else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = (getHeight() - r.height()) / 2f - r.top;
            else if (r.top > 0) dy = -r.top;
            else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            m.postTranslate(dx, dy);
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) { super.onSizeChanged(w, h, ow, oh); fit(); }

        @Override public void setImageBitmap(Bitmap b) { super.setImageBitmap(b); fit(); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            sg.onTouchEvent(e);
            if (!sg.isInProgress()) gd.onTouchEvent(e);
            return true;
        }
    }

    // ---------------- video ----------------
    void showVideo(File f) {
        vv = new VideoView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        stage.addView(vv, lp);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        vv.setOnPreparedListener(m -> vv.start());
        vv.setOnErrorListener((m, w, x) -> { Ui.toast(this, "This video can't be played here — try \"Open with\""); return true; });
        vv.setVideoPath(f.getAbsolutePath());
    }

    // ---------------- audio ----------------
    void showAudio(File f, Entry e) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setBackground(Ui.glass(30, true));
        card.setPadding(Ui.dp(24), Ui.dp(28), Ui.dp(24), Ui.dp(22));
        final ImageView art = new ImageView(this);
        art.setImageDrawable(Glyphs.tile(FileKinds.AUDIO));
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Ui.round(art, 28);
        card.addView(art, new LinearLayout.LayoutParams(Ui.dp(180), Ui.dp(180)));
        TextView nm = Ui.tv(this, f.getName(), 18, Ui.WHITE, true);
        nm.setGravity(Gravity.CENTER);
        nm.setPadding(0, Ui.dp(18), 0, 0);
        card.addView(nm, new LinearLayout.LayoutParams(-1, -2));
        final TextView meta = Ui.tv(this, "", 13, Ui.SUB, false);
        meta.setGravity(Gravity.CENTER);
        meta.setPadding(0, Ui.dp(6), 0, Ui.dp(14));
        card.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        final SeekBar sb = new SeekBar(this);
        sb.getProgressDrawable().setTint(Ui.accent);
        sb.getThumb().setTint(Ui.accent);
        card.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        final TextView time = Ui.tv(this, "0:00 / 0:00", 12, Ui.SUB, false);
        time.setGravity(Gravity.CENTER);
        card.addView(time, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout ctl = new LinearLayout(this);
        ctl.setGravity(Gravity.CENTER);
        ImageView pv = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        final ImageView pp = Ui.iconBtn(this, Glyphs.PAUSE, Ui.WHITE);
        ImageView nx = Ui.iconBtn(this, Glyphs.NEXT, Ui.WHITE);
        pp.setBackground(Ui.accentPill(30));
        pv.setOnClickListener(v -> go(-1));
        nx.setOnClickListener(v -> go(1));
        ctl.addView(pv, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));
        LinearLayout.LayoutParams ppl = new LinearLayout.LayoutParams(Ui.dp(64), Ui.dp(64));
        ppl.setMargins(Ui.dp(18), 0, Ui.dp(18), 0);
        ctl.addView(pp, ppl);
        ctl.addView(nx, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));
        LinearLayout.LayoutParams cll = new LinearLayout.LayoutParams(-1, -2);
        cll.topMargin = Ui.dp(10);
        card.addView(ctl, cll);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        fp.setMargins(Ui.dp(22), 0, Ui.dp(22), 0);
        stage.addView(card, fp);

        final int my = idx;
        io.execute(() -> {
            String info = "";
            Bitmap cover = null;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(f.getAbsolutePath());
                String ar = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                String al = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                info = (ar != null ? ar : "") + (ar != null && al != null ? " • " : "") + (al != null ? al : "");
                byte[] pic = r.getEmbeddedPicture();
                if (pic != null) cover = BitmapFactory.decodeByteArray(pic, 0, pic.length);
            } catch (Throwable ignored) { } finally { try { r.release(); } catch (Throwable ignored) { } }
            final String fi = info.isEmpty() ? Ui.size(e.len) : info;
            final Bitmap fc = cover;
            h.post(() -> { if (destroyed || my != idx) return; meta.setText(fi); if (fc != null) art.setImageBitmap(fc); });
        });

        try {
            mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(m -> {
                sb.setMax(m.getDuration());
                m.start();
                pp.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE));
                startTicker(sb, time);
            });
            mp.setOnCompletionListener(m -> {
                if (idx < paths.size() - 1) go(1);
                else pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE));
            });
            mp.setOnErrorListener((m, w, x) -> { Ui.toast(this, "Can't play this audio file"); return true; });
            mp.prepareAsync();
        } catch (Exception ex) {
            Ui.toast(this, "Can't play this audio file");
        }
        pp.setOnClickListener(v -> {
            if (mp == null) return;
            try {
                if (mp.isPlaying()) { mp.pause(); pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE)); }
                else { mp.start(); pp.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE)); }
            } catch (Exception ignored) { }
        });
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user && mp != null) { try { mp.seekTo(p); } catch (Exception ignored) { } } }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
    }

    static String fmt(int ms) { int s = ms / 1000; return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60); }

    void startTicker(final SeekBar sb, final TextView time) {
        ticker = new Runnable() {
            @Override public void run() {
                if (mp == null || destroyed) return;
                try {
                    int p = mp.getCurrentPosition();
                    sb.setProgress(p);
                    time.setText(fmt(p) + " / " + fmt(mp.getDuration()));
                } catch (Exception ignored) { }
                h.postDelayed(this, 400);
            }
        };
        h.post(ticker);
    }

    // ---------------- text ----------------
    void showText(final File f) {
        final ScrollView sv = new ScrollView(this);
        final TextView t = new TextView(this);
        t.setTextColor(0xFFE6EAF5);
        t.setTextSize(13);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setPadding(Ui.dp(18), Ui.dp(72) + topInset, Ui.dp(18), Ui.dp(40) + bottomInset);
        t.setText("Loading…");
        sv.addView(t, new FrameLayout.LayoutParams(-1, -2));
        stage.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        final int my = idx;
        io.execute(() -> {
            String s;
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[300 * 1024];
                int n = in.read(buf);
                s = new String(buf, 0, Math.max(n, 0), "UTF-8");
                if (f.length() > buf.length) s += "\n\n… file truncated (showing first 300 KB)";
            } catch (Exception ex) { s = "Can't read this file."; }
            final String fs = s;
            h.post(() -> { if (!destroyed && my == idx) t.setText(fs); });
        });
    }

    // ---------------- pdf ----------------
    void showPdf(File f) {
        try {
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            pdf = new PdfRenderer(pfd);
        } catch (Exception ex) {
            Ui.toast(this, "Can't open this PDF here — try \"Open with\"");
            return;
        }
        final PdfRenderer r = pdf;
        final int count = r.getPageCount();
        final int w = getResources().getDisplayMetrics().widthPixels;
        final LruCache<Integer, Bitmap> cache = new LruCache<>(6);
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setClipToPadding(false);
        lv.setPadding(0, Ui.dp(72) + topInset, 0, Ui.dp(24) + bottomInset);
        lv.setVerticalScrollBarEnabled(false);
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return count; }
            @Override public Object getItem(int i) { return null; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int pos, View cv, ViewGroup parent) {
                final ImageView iv;
                if (cv == null) {
                    iv = new ImageView(ViewerActivity.this);
                    iv.setAdjustViewBounds(true);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    iv.setBackgroundColor(Color.WHITE);
                    AbsListView.LayoutParams lp = new AbsListView.LayoutParams(-1, -2);
                    iv.setLayoutParams(lp);
                } else iv = (ImageView) cv;
                iv.setTag(pos);
                Bitmap b = cache.get(pos);
                if (b != null) { iv.setImageBitmap(b); iv.setMinimumHeight(0); }
                else {
                    iv.setImageDrawable(null);
                    iv.setMinimumHeight((int) (w * 1.35f));
                    io.execute(() -> {
                        Bitmap bm = renderPage(r, pos, w);
                        if (bm == null) return;
                        cache.put(pos, bm);
                        h.post(() -> {
                            Object tg = iv.getTag();
                            if (!destroyed && tg != null && ((Integer) tg) == pos) { iv.setImageBitmap(bm); iv.setMinimumHeight(0); }
                        });
                    });
                }
                return iv;
            }
        });
        stage.addView(lv, new FrameLayout.LayoutParams(-1, -1));
    }

    static Bitmap renderPage(PdfRenderer r, int pos, int w) {
        try {
            synchronized (r) {
                PdfRenderer.Page p = r.openPage(pos);
                float sc = (float) w / p.getWidth();
                Bitmap b = Bitmap.createBitmap(w, Math.max(1, (int) (p.getHeight() * sc)), Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                p.close();
                return b;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    @Override protected void onPause() {
        super.onPause();
        try { if (mp != null && mp.isPlaying()) mp.pause(); } catch (Exception ignored) { }
        try { if (vv != null && vv.isPlaying()) vv.pause(); } catch (Exception ignored) { }
    }

    @Override protected void onDestroy() {
        destroyed = true;
        cleanup();
        io.shutdown();
        super.onDestroy();
    }
}
